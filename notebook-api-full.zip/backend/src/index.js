/* 班級專區 API（Cloudflare Worker）。所有驗證、出卷、判分、積分都在這裡。
   前端只能：登入（Firebase）→ 要題目 → 送答案 → 看結果。 */
import { verifyToken, normEmail, AuthError } from "./auth.js";
import { blank, norm, ymd, rec, touchDay, award, mockBonus, overCap, tot, lv, dueList, cfgOf, stkProgress, hintUsed, addDays, STK_PUBLIC } from "./game.js";
import { buildQuiz, buildMock, buildDaily, isCorrect, diagnose, publicQ, fixedToQ, pickMany, letterOf } from "./exam.js";
import { GEN_IDS, GENS, runGen, rng, gradeOf, shuffle } from "./gen.js";
import { checkBank, checkRoster } from "./validate.js";

class HttpError extends Error { constructor(status, code) { super(code); this.status = status; this.code = code; } }
const bad = (code, status = 400) => new HttpError(status, code);

/* ---- 資料：名單、題庫、設定都存在 D1，由老師後台編輯 ----
   用「版本號」判斷有沒有更新（每 10 秒只讀 1 列），有更新才整批重新載入。
   還沒把舊的 Google 試算表資料搬進 D1 之前（roster 表是空的），暫時沿用 KV 裡的舊資料，網站照常運作。 */
let mem = { t: 0, ver: null, at: 0, bank: [], roster: new Map(), rosterRows: [], settings: {}, legacy: false };
const TTL = 10e3;
const bump = async (env) => { await env.DB.prepare("INSERT INTO settings(k,v) VALUES('ver',?) ON CONFLICT(k) DO UPDATE SET v=excluded.v").bind(Date.now() + ":" + Math.random()).run(); mem.t = 0; mem.ver = null; };
let ensured = false;
/* 舊資料庫沒有 expires（授權到期日）欄位時，自動補上，不需要老師手動改資料庫 */
async function ensureCols(env) {
  if (ensured) return; ensured = true;
  try { await env.DB.prepare("SELECT expires FROM roster LIMIT 1").first(); }
  catch { try { await env.DB.prepare("ALTER TABLE roster ADD COLUMN expires TEXT NOT NULL DEFAULT ''").run(); } catch {} }
}
async function data(env) {
  if (Date.now() - mem.t < TTL) return mem;
  await ensureCols(env);
  const v = await env.DB.prepare("SELECT v FROM settings WHERE k='ver'").first(), ver = v ? v.v : "0";
  if (mem.ver === ver && !(mem.legacy && Date.now() - mem.at > 60e3)) { mem.t = Date.now(); return mem; }
  const [b, r, c] = await Promise.all([env.DB.prepare("SELECT * FROM bank").all(), env.DB.prepare("SELECT * FROM roster").all(), env.DB.prepare("SELECT v FROM settings WHERE k='cfg'").first()]);
  let bank = b.results || [], rows = r.results || [], legacy = false;
  if (!rows.length && env.KV) { rows = (await env.KV.get("roster", "json")) || []; if (!bank.length) bank = (await env.KV.get("bank", "json")) || []; legacy = rows.length > 0; }
  const roster = new Map();
  rows.forEach((x) => { if (x.active !== "0" && x.active !== 0) roster.set(normEmail(x.email), x); });
  let settings = {}; try { settings = c ? JSON.parse(c.v) : {}; } catch {}
  mem = { t: Date.now(), ver, at: Date.now(), bank, roster, rosterRows: rows, settings, legacy };
  return mem;
}
const CFG = (env) => cfgOf({ ...env, ...mem.settings });

/* ---- CORS ---- */
function corsHeaders(req, env) {
  const o = req.headers.get("Origin") || "", list = String(env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);
  const okLocal = env.ALLOW_LOCALHOST === "1" && /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o);
  const h = { "Vary": "Origin", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
  if (list.includes(o) || okLocal) {
    h["Access-Control-Allow-Origin"] = o;
    h["Access-Control-Allow-Headers"] = "Authorization, Content-Type";
    h["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS";
    h["Access-Control-Max-Age"] = "600";
  }
  return h;
}
const out = (obj, status, h) => new Response(JSON.stringify(obj), { status, headers: { ...h, "Content-Type": "application/json; charset=utf-8" } });

/* ---- 三種身分：admin 管理員（全部）、teacher 老師（只管自己的班）、student 學生 ----
   老師在名單的「班級」欄可以寫多個班，例如 601,602；管理員不受限。 */
const isStaff = (row) => !!row && (row.role === "teacher" || row.role === "admin");
const classesOf = (row) => String(row.class ?? "").split(/[,，、;；\s]+/).filter(Boolean);
const ownsClass = (user, cls) => !!user.admin || (user.classes || []).includes(String(cls));
const needClass = (user, cls) => { if (!ownsClass(user, cls)) throw bad("forbidden", 403); };
/* 只能動自己班的「學生」；老師與管理員的資料只有管理員能動 */
const canTouch = (user, row) => !!row && (!!user.admin || (!isStaff(row) && ownsClass(user, row.class)));

/* ---- 使用者與個人資料 ---- */
async function authed(req, env) {
  const m = /^Bearer (.+)$/.exec(req.headers.get("Authorization") || "");
  if (!m) throw bad("no_token", 401);
  let id;
  try { id = await verifyToken(m[1], env); } catch (e) { if (e instanceof AuthError) throw bad("bad_token", 401); throw e; }
  const D = await data(env), row = D.roster.get(normEmail(id.email));
  if (!row) throw bad("not_in_roster", 403);
  const user = { email: normEmail(id.email), uid: id.uid, cls: String(row.class), no: +row.no || 0, name: row.name || "座號" + row.no, role: isStaff(row) ? "teacher" : "student", admin: row.role === "admin", classes: classesOf(row), grade: Math.min(6, Math.max(1, +row.grade || 6)) };
  // 帳號授權期限（含當天）。管理員不受限；過期的學生只能看自己的資料，不能練習、考試、列印；過期的老師進不了後台
  const exp = /^\d{4}-\d{2}-\d{2}$/.test(String(row.expires || "")) ? String(row.expires) : "";
  user.expires = exp; user.expired = !user.admin && !!exp && ymd() > exp; // 管理員不受期限限制；老師過期＝後台停權
  user.daysLeft = exp ? Math.round((Date.parse(exp) - Date.parse(ymd())) / 864e5) : null;
  return { user, bank: D.bank, roster: D.roster };
}
async function loadProfile(env, u) {
  const r = await env.DB.prepare("SELECT data,cls,no,name,role,grade FROM profiles WHERE email=?").bind(u.email).first();
  if (!r) {
    const D = blank();
    await env.DB.prepare("INSERT OR IGNORE INTO profiles(email,cls,no,name,role,grade,data,updated) VALUES(?,?,?,?,?,?,?,?)")
      .bind(u.email, u.cls, u.no, u.name, u.role, u.grade, JSON.stringify(D), Date.now()).run();
    return D;
  }
  // 名單（試算表）改了班級、座號、名字時才同步，避免每次請求都寫資料庫
  if (r.cls !== u.cls || r.no !== u.no || r.name !== u.name || r.role !== u.role || r.grade !== u.grade)
    await env.DB.prepare("UPDATE profiles SET cls=?,no=?,name=?,role=?,grade=? WHERE email=?").bind(u.cls, u.no, u.name, u.role, u.grade, u.email).run();
  return norm(JSON.parse(r.data));
}
const saveProfile = (env, u, D) => env.DB.prepare("UPDATE profiles SET data=?, updated=? WHERE email=?").bind(JSON.stringify(D), Date.now(), u.email);

async function body(req, max = 20000) {
  const t = await req.text();
  if (t.length > max) throw bad("too_big", 413);
  try { return t ? JSON.parse(t) : {}; } catch { throw bad("bad_json"); }
}

/* ---- 作答階段（session） ---- */
const MOCK_SECONDS = 1200, GRACE = 10;
async function newSession(env, u, kind, qs, extra = {}, seconds = MOCK_SECONDS) {
  const id = crypto.randomUUID(), now = Date.now();
  const deadline = kind === "mock" ? now + seconds * 1000 : null;
  await env.DB.prepare("INSERT INTO sessions(id,email,kind,created,deadline,done,state) VALUES(?,?,?,?,?,0,?)")
    .bind(id, u.email, kind, now, deadline, JSON.stringify({ qs, ans: {}, ...extra })).run();
  if (Math.random() < 0.05) {
    await env.DB.prepare("DELETE FROM sessions WHERE created<?").bind(now - 2 * 864e5).run();
    await env.DB.prepare("DELETE FROM attempts WHERE ts<?").bind(now - 180 * 864e5).run();
    await env.DB.prepare("DELETE FROM once WHERE ts<?").bind(now - 3 * 864e5).run();
  }
  return { sid: id, kind, deadline, seconds: kind === "mock" ? seconds : 0, qs: qs.map(publicQ), ...extra };
}
async function getSession(env, u, sid, kinds) {
  const s = await env.DB.prepare("SELECT * FROM sessions WHERE id=? AND email=?").bind(String(sid), u.email).first();
  if (!s) throw bad("no_session", 404);
  if (s.done) throw bad("already_done", 409);
  if (kinds && !kinds.includes(s.kind)) throw bad("wrong_kind");
  return { ...s, st: JSON.parse(s.state) };
}
/* 「只能發生一次」的鎖：用資料庫唯一鍵擋住同時送出的重複請求（連點、開多個分頁、寫程式狂送），
   重複的那一筆會讓整個批次回滾，積分不會重複發。 */
const once = (env, k) => env.DB.prepare("INSERT INTO once(k,ts) VALUES(?,?)").bind(k, Date.now());
async function commit(env, stmts) {
  try { await env.DB.batch(stmts); }
  catch (e) { if (/UNIQUE|constraint/i.test(String((e && e.message) || e))) throw bad("already_done", 409); throw e; }
}
const saveSession = (env, s, done) => env.DB.prepare("UPDATE sessions SET state=?, done=? WHERE id=?").bind(JSON.stringify(s.st), done ? 1 : 0, s.id);
const attempt = (env, u, q, ok, dg) => env.DB.prepare("INSERT INTO attempts(email,cls,unit,qid,ok,dg,ts) VALUES(?,?,?,?,?,?,?)").bind(u.email, u.cls, q.unit, q.qid || "", ok ? 1 : 0, dg || "", Date.now());

/* ---- 路由 ---- */
/* 正式學員功能（練習、考試、列印、排行榜）：授權過期就擋掉 */
const member = async (req, env) => { const a = await authed(req, env); if (a.user.expired) throw bad("expired", 403); return a; };
const teacher = async (req, env) => { const a = await authed(req, env); if (a.user.role !== "teacher") throw bad("forbidden", 403); if (a.user.expired) throw bad("expired", 403); return a; };
const adminOnly = async (req, env) => { const a = await teacher(req, env); if (!a.user.admin) throw bad("forbidden", 403); return a; };
const UNIT_RE = /^[1-6][ud]-\d{1,2}\.\d{1,2}$/;
const routes = {
  "GET /api/health": async () => ({ ok: true }),

  "GET /api/me": async (req, env) => {
    const { user, bank } = await authed(req, env);
    const D = await loadProfile(env, user);
    const units = [...new Set([...GEN_IDS, ...bank.filter((x) => x.active !== "0").map((x) => x.unit)])];
    const cfg = CFG(env), pu = [...new Set([...GEN_IDS, ...bank.filter((x) => x.active !== "0" && x.print !== "0").map((x) => x.unit)])];
    return { user: { name: user.name, cls: user.cls, no: user.no, role: user.role, admin: !!user.admin, grade: user.grade }, data: D, stk: STK_PUBLIC, prog: stkProgress(D, CFG(env)), today: ymd(), units, gens: pu, cfg: { step: cfg.step, pts: cfg.pts, capQ: cfg.capQ, capMock: cfg.capMock, review: cfg.review, hint: cfg.hint }, acct: { expires: user.expires, expired: user.expired, daysLeft: user.daysLeft } };
  },

  "POST /api/seen": async (req, env) => {
    const { user } = await authed(req, env), b = await body(req);
    const ids = (Array.isArray(b.ids) ? b.ids : []).filter((x) => UNIT_RE.test(String(x))).slice(0, 60);
    if (!ids.length) return { ok: true };
    const D = await loadProfile(env, user); let ch = false;
    ids.forEach((id) => { const x = (D.u[id] = D.u[id] || { n: 0, c: 0 }); if (!x.seen) { x.seen = 1; ch = true; } });
    if (ch) await saveProfile(env, user, D).run();
    return { ok: true };
  },

  "POST /api/start": async (req, env) => {
    const { user, bank } = await member(req, env), b = await body(req), D = await loadProfile(env, user), t = ymd();
    if (b.kind === "quiz") {
      if (!UNIT_RE.test(String(b.unit))) throw bad("bad_unit");
      const qs = buildQuiz(b.unit, bank, Math.random);
      if (!qs.length) return { empty: true };
      return await newSession(env, user, "quiz", qs, { unit: b.unit, pts0: D.pts });
    }
    if (b.kind === "mock") {
      // 模擬卷可自選單元（0 個＝依年級細目表）與題數（5～30 題；每題 2 分鐘）
      const us = [...new Set((Array.isArray(b.units) ? b.units : []).map(String).filter((x) => UNIT_RE.test(x)))].slice(0, 60), n = Math.min(30, Math.max(5, Math.floor(+b.n) || 10));
      const qs = buildMock(user.grade, bank, Math.random, n, us);
      if (!qs.length) return { empty: true };
      return { ...(await newSession(env, user, "mock", qs, { n: qs.length, small: qs.length < 8 }, qs.length * 120)), short: qs.meta.short, filled: qs.meta.filled, small: qs.length < 8 };
    }
    if (b.kind === "daily") {
      const q = buildDaily(user.grade, user.cls, t, bank);
      if (D.dq[t]) return { done: true, ok: D.dq[t].ok, q: q.q, a: q.a, h: q.h, img: q.img || undefined, himg: q.himg || undefined };
      // 今天已經開過、還沒作答的每日一題就沿用同一份，不要每次進來都新開一份
      const open = await env.DB.prepare("SELECT id,state FROM sessions WHERE email=? AND kind='daily' AND done=0 AND created>? ORDER BY created DESC LIMIT 1").bind(user.email, Date.now() - 36e5 * 24).first();
      if (open) { const st = JSON.parse(open.state); if (!Object.keys(st.ans).length && st.qs[0] && st.qs[0].q === q.q) return { sid: open.id, kind: "daily", deadline: null, seconds: 0, qs: st.qs.map(publicQ), pts0: st.pts0 }; }
      return await newSession(env, user, "daily", [q], { pts0: D.pts });
    }
    if (b.kind === "fix") {
      const qs = dueList(D, t).slice(0, 10).map((w) => ({ unit: w.id, qid: "wrong", q: w.q, o: w.o ? shuffle(w.o, Math.random) : null, t: w.t, alt: w.alt, a: w.a, h: w.h || "", d: {}, lv: w.lv || 2, img: w.img || "", himg: w.himg || "" }));
      if (!qs.length) return { empty: true, wrong: D.wr.length };
      return await newSession(env, user, "fix", qs, { pts0: D.pts });
    }
    throw bad("bad_kind");
  },

  /* 練習模式：一題一題檢查 */
  "POST /api/check": async (req, env) => {
    const { user } = await member(req, env), b = await body(req), s = await getSession(env, user, b.sid, ["quiz", "daily", "fix"]);
    const i = +b.i, q = s.st.qs[i];
    if (!q) throw bad("bad_index");
    if (s.st.ans[i] !== undefined) throw bad("already_answered", 409);
    const D = await loadProfile(env, user), cfg = CFG(env), ok = isCorrect(q, b.v), dg = ok ? "" : diagnose(q, b.v), t = ymd(), extra = {}, hinted = !!(s.st.hint && s.st.hint[i]), mult = hinted ? 0.5 : 1; // 看過提示的題目答對只拿一半積分
    s.st.ans[i] = { v: b.v === undefined ? null : b.v, ok };
    const stmts = [once(env, `chk:${s.id}:${i}`)];
    if (s.kind === "daily") {
      // 每日一題：答案送出的當下就算完成並發分（一天只有一次機會），不再需要另外「結算」
      if (D.dq[t]) throw bad("already_done", 409);
      const pts0 = D.pts;
      rec(D, q, ok, false, cfg, t, true);
      D.dq[t] = { ok }; D.pts += ok ? Math.floor(30 * mult) : 5; touchDay(D);
      extra.got = award(D, cfg); extra.gain = D.pts - pts0; extra.data = D; extra.prog = stkProgress(D, cfg);
      stmts.push(once(env, `daily:${user.email}:${t}`));
    } else rec(D, q, ok, s.kind === "fix", cfg, t, false, mult);
    await commit(env, [...stmts, saveSession(env, s, false), saveProfile(env, user, D), attempt(env, user, q, ok, dg)]);
    return { ok, a: q.a, al: letterOf(q) || undefined, h: q.h, himg: q.himg || undefined, diag: dg, fixLeft: s.kind === "fix" ? D.wr.some((w) => w.k === q.unit + "|" + q.q) : undefined, ...extra };
  },
  /* 看提示：每題第一次看要扣分（預設 3 分，老師可調），而且這題答對只拿一半積分；已經答完的題目不能再看 */
  "POST /api/hint": async (req, env) => {
    const { user } = await member(req, env), b = await body(req), s = await getSession(env, user, b.sid, ["quiz", "daily", "fix"]);
    const i = +b.i, q = s.st.qs[i];
    if (!q) throw bad("bad_index");
    if (s.st.ans[i] !== undefined) throw bad("already_answered", 409);
    s.st.hint = s.st.hint || {};
    if (s.st.hint[i]) return { h: q.h, himg: q.himg || undefined, cost: 0, again: true };
    const D = await loadProfile(env, user), cfg = CFG(env), cost = hintUsed(D, cfg);
    s.st.hint[i] = 1;
    try { await commit(env, [once(env, `hint:${s.id}:${i}`), saveSession(env, s, false), saveProfile(env, user, D)]); }
    catch (e) { if (e.code === "already_done") return { h: q.h, himg: q.himg || undefined, cost: 0, again: true }; throw e; }
    return { h: q.h, himg: q.himg || undefined, cost, pts: D.pts, data: D };
  },
  "POST /api/finish": async (req, env) => {
    const { user } = await member(req, env), b = await body(req), s = await getSession(env, user, b.sid, ["quiz", "daily", "fix"]);
    const D = await loadProfile(env, user), pts0 = s.st.pts0 ?? D.pts, a = Object.values(s.st.ans), n = a.length, c = a.filter((x) => x.ok).length, t = ymd();
    if (s.kind === "quiz" && !overCap(D, CFG(env))) { if (n >= 3) D.pts += 20; if (n >= 5 && c === n && !Object.keys(s.st.hint || {}).length) D.pf++; }
    if (n && s.kind !== "daily") touchDay(D); // 每日一題在作答時已經處理過
    const got = award(D, CFG(env));
    await commit(env, [once(env, `fin:${s.id}`), saveSession(env, s, true), saveProfile(env, user, D)]);
    return { n, c, gain: D.pts - pts0, got, data: D, prog: stkProgress(D, CFG(env)) };
  },

  /* 模擬卷：交卷時一次判分 */
  "POST /api/submit": async (req, env) => {
    const { user } = await member(req, env), b = await body(req), s = await getSession(env, user, b.sid, ["mock"]);
    const late = Date.now() > s.deadline + GRACE * 1000, ans = Array.isArray(b.ans) ? b.ans : [];
    const D = await loadProfile(env, user), pts0 = D.pts, review = [], stmts = [];
    let c = 0;
    s.st.qs.forEach((q, i) => {
      const v = late ? null : ans[i], ok = isCorrect(q, v), dg = ok ? "" : diagnose(q, v);
      if (ok) c++;
      rec(D, q, ok, false, CFG(env));
      stmts.push(attempt(env, user, q, ok, dg));
      if (!ok) review.push({ i, q: q.q, o: q.o || undefined, img: q.img || undefined, himg: q.himg || undefined, unit: q.unit, v: v === undefined ? null : v, a: q.a, h: q.h, diag: dg });
    });
    const n = s.st.qs.length, sc = Math.round((c / n) * 100);
    mockBonus(D, sc, CFG(env), ymd(), !!s.st.small); touchDay(D);
    const got = award(D, CFG(env));
    s.st.ans = { submitted: true };
    await commit(env, [once(env, `fin:${s.id}`), saveSession(env, s, true), saveProfile(env, user, D), ...stmts]);
    return { sc, c, n, late, gain: D.pts - pts0, got, review, data: D, prog: stkProgress(D, CFG(env)) };
  },

  "GET /api/board": async (req, env) => {
    const { user } = await member(req, env);
    const { results } = await env.DB.prepare("SELECT no,name,data FROM profiles WHERE cls=? AND role='student'").bind(user.cls).all();
    const rows = (results || []).map((r) => { const D = norm(JSON.parse(r.data)), t = tot(D); return { no: r.no, n: r.name, pts: D.pts, lv: lv(D, CFG(env)), stk: Object.keys(D.stk).length, ok: t.c, tot: t.n }; }).filter((x) => x.tot > 0);
    return { rows, me: user.no };
  },

  /* 列印練習卷（出卷）。src=mix（綜合）｜wrong（錯題）｜單元代號；或 units=a,b,c 自選多個單元。n=5～40。
     從各單元輪流出題（產生器＋固定題混合）；某單元不重複的題目用完，就用同年級的其他單元補滿，並回傳 filled 讓前端說明。
     選擇題的選項隨機排列，並附正確選項字母 al。老師可用 g=3..6 指定年級 */
  "GET /api/print": async (req, env) => {
    const { user, bank } = await member(req, env), url = new URL(req.url), src = url.searchParams.get("src") || "mix";
    const n = Math.min(40, Math.max(5, Math.floor(+url.searchParams.get("n")) || 10)), r = rng(Date.now() + ":" + Math.random());
    const grade = user.role === "teacher" && [1, 2, 3, 4, 5, 6].includes(+url.searchParams.get("g")) ? +url.searchParams.get("g") : user.grade;
    const pack = (q0) => { const q = q0.o ? { ...q0, o: shuffle(q0.o, r) } : q0; return { unit: q.unit, q: q.q, o: q.o || undefined, al: letterOf(q) || undefined, img: q.img || undefined, a: q.a, h: q.h, himg: q.himg || undefined }; };
    const printable = bank.filter((x) => x.active !== "0" && x.print !== "0");
    const allUnits = [...new Set([...GEN_IDS, ...printable.map((x) => x.unit)])];
    let qs = [], name = "", filled = 0, sel = [];
    const picked = (url.searchParams.get("units") || "").split(",").map((x) => x.trim()).filter((x) => UNIT_RE.test(x));
    if (src === "wrong") { const D = await loadProfile(env, user); qs = D.wr.slice(0, n).map((w) => pack({ unit: w.id, q: w.q, o: w.o, img: w.img, a: w.a, h: w.h, himg: w.himg })); name = "錯題重練"; }
    else {
      if (picked.length) sel = [...new Set(picked)].filter((u) => allUnits.includes(u)).slice(0, 60);
      else if (UNIT_RE.test(src)) sel = [src];
      else sel = allUnits.filter((u) => gradeOf(u) <= grade && gradeOf(u) >= grade - 1);
      if (!sel.length) throw bad("no_questions");
      const seen = new Set(), fx = (x) => true;
      let got = pickMany({ units: sel, bank, n, r, seen });
      if (got.length < n && (picked.length || UNIT_RE.test(src))) {
        const gs = [...new Set(sel.map(gradeOf))], more = shuffle(allUnits.filter((u) => gs.includes(gradeOf(u)) && !sel.includes(u)), r);
        const ex = pickMany({ units: more, bank, n: n - got.length, r, seen }); filled = ex.length; got = got.concat(ex);
      }
      qs = got.map(pack);
      name = sel.length === 1 ? sel[0] : picked.length ? "自選 " + sel.length + " 個單元" : "綜合練習";
    }
    return { name, qs, want: n, short: Math.max(0, n - qs.length), filled };
  },

  /* 老師後台：班級總覽與深度分析 */
  "GET /api/admin/overview": async (req, env) => {
    const { user, roster } = await authed(req, env);
    if (user.role !== "teacher") throw bad("forbidden", 403);
    const classes = [...new Set([...roster.values()].filter((x) => !isStaff(x)).map((x) => String(x.class)))].filter((c) => ownsClass(user, c)).sort(), url = new URL(req.url);
    const cls = classes.includes(url.searchParams.get("cls")) ? url.searchParams.get("cls") : classes[0];
    const now = Date.now(), since = now - 30 * 864e5, today = ymd(), cfg = CFG(env);
    const [st, un, ms, dg, dd, hr] = await Promise.all([
      env.DB.prepare("SELECT email,no,name,data,updated FROM profiles WHERE cls=? AND role='student' ORDER BY no").bind(cls).all(),
      env.DB.prepare("SELECT unit, COUNT(*) n, SUM(ok) c, COUNT(DISTINCT email) s FROM attempts WHERE cls=? AND ts>? GROUP BY unit ORDER BY unit").bind(cls, since).all(),
      env.DB.prepare("SELECT qid, unit, COUNT(*) n, SUM(1-ok) w FROM attempts WHERE cls=? AND ts>? GROUP BY qid, unit HAVING w>0 ORDER BY w DESC LIMIT 12").bind(cls, since).all(),
      env.DB.prepare("SELECT unit, dg, COUNT(*) n FROM attempts WHERE cls=? AND ts>? AND dg!='' GROUP BY unit, dg ORDER BY n DESC LIMIT 12").bind(cls, since).all(),
      env.DB.prepare("SELECT CAST((ts+28800000)/86400000 AS INTEGER) d, COUNT(*) n, SUM(ok) c, COUNT(DISTINCT email) s FROM attempts WHERE cls=? AND ts>? GROUP BY d ORDER BY d").bind(cls, since).all(),
      env.DB.prepare("SELECT CAST(((ts+28800000)/3600000)%24 AS INTEGER) h, COUNT(*) n FROM attempts WHERE cls=? AND ts>? GROUP BY h ORDER BY h").bind(cls, since).all(),
    ]);
    const lim7 = addDays(today, -7), emailOf = new Map([...roster.values()].map((x) => [normEmail(x.email), x]));
    const have = new Set((st.results || []).map((r) => r.no)), students = (st.results || []).map((r) => {
      const D = norm(JSON.parse(r.data)), t = tot(D), mk = D.mk.slice(-3), ro = emailOf.get(normEmail(r.email)) || {};
      const days7 = Object.keys(D.day).filter((k) => k > lim7), n7 = days7.reduce((a, k) => a + D.day[k].n, 0), c7 = days7.reduce((a, k) => a + D.day[k].c, 0), h7 = days7.reduce((a, k) => a + (D.day[k].h || 0), 0);
      const exp = /^\d{4}-\d{2}-\d{2}$/.test(String(ro.expires || "")) ? ro.expires : "", left = exp ? Math.round((Date.parse(exp) - Date.parse(today)) / 864e5) : null;
      const flags = [];
      if (!r.updated || !D.sk.last || D.sk.last < lim7) flags.push("7 天沒練習");
      if (t.n >= 20 && t.c / t.n < 0.6) flags.push("答對率偏低");
      if (n7 >= 10 && c7 / n7 < 0.5) flags.push("近 7 天明顯退步");
      if (D.hn >= 10 && D.hn / Math.max(1, t.n) > 0.3) flags.push("很依賴提示");
      if (D.wr.length >= 30) flags.push("錯題堆積");
      if (left !== null && left <= 14) flags.push(left < 0 ? "授權已到期" : "授權 " + left + " 天後到期");
      return { email: r.email, no: r.no, name: r.name, pts: D.pts, lv: lv(D, cfg), n: t.n, c: t.c, n7, c7, streak: D.sk.n, days: D.dn, last: D.sk.last, mock: mk.length ? Math.round(mk.reduce((a, m) => a + m.sc, 0) / mk.length) : null, mockN: D.mkn, wrong: D.wr.length, hints: D.hn || 0, h7, badges: Object.keys(D.stk).length, expires: exp, left, flags };
    });
    const never = [...roster.values()].filter((x) => String(x.class) === cls && x.role !== "teacher" && !have.has(+x.no)).map((x) => ({ no: +x.no, name: x.name, expires: x.expires || "" }));
    const act = students.filter((x) => x.last >= lim7), sum = students.reduce((a, x) => ({ n: a.n + x.n, c: a.c + x.c, hints: a.hints + x.hints }), { n: 0, c: 0, hints: 0 });
    const daily = (dd.results || []).map((x) => ({ d: new Date(x.d * 864e5).toISOString().slice(0, 10), n: x.n, c: x.c, s: x.s }));
    const mocks = students.filter((x) => x.mock !== null).map((x) => x.mock);
    return { legacy: mem.legacy, classes, cls, students, never, units: un.results || [], missed: ms.results || [], misconceptions: dg.results || [], daily, hours: hr.results || [],
      summary: { total: students.length + never.length, joined: students.length, active7: act.length, acc: sum.n ? Math.round((sum.c / sum.n) * 100) : null, n: sum.n, hints: sum.hints, mockAvg: mocks.length ? Math.round(mocks.reduce((a, x) => a + x, 0) / mocks.length) : null, atRisk: students.filter((x) => x.flags.length).length }, hintCost: cfg.hint };
  },
  /* 單一學生的深入檔案：各單元表現、21 天日誌、模擬卷走勢、錯題本、勳章、最近的迷思 */
  "GET /api/admin/student": async (req, env) => {
    const { user, roster } = await authed(req, env);
    if (user.role !== "teacher") throw bad("forbidden", 403);
    const url = new URL(req.url), cls = String(url.searchParams.get("cls") || ""), no = +url.searchParams.get("no"); needClass(user, cls);
    const r = await env.DB.prepare("SELECT email,no,name,data FROM profiles WHERE cls=? AND no=? AND role='student'").bind(cls, no).first();
    if (!r) throw bad("not_found", 404);
    const D = norm(JSON.parse(r.data)), since = Date.now() - 30 * 864e5;
    const [un, dg] = await Promise.all([
      env.DB.prepare("SELECT unit, COUNT(*) n, SUM(ok) c FROM attempts WHERE email=? AND ts>? GROUP BY unit ORDER BY unit").bind(r.email, since).all(),
      env.DB.prepare("SELECT unit, dg, COUNT(*) n FROM attempts WHERE email=? AND ts>? AND dg!='' GROUP BY unit, dg ORDER BY n DESC LIMIT 8").bind(r.email, since).all(),
    ]);
    const t = tot(D);
    return { no: r.no, name: r.name, pts: D.pts, lv: lv(D, CFG(env)), n: t.n, c: t.c, streak: D.sk.n, days: D.dn, hints: D.hn || 0, units: un.results || [], overall: Object.entries(D.u).map(([id, x]) => ({ unit: id, n: x.n, c: x.c })),
      log: Object.keys(D.day).sort().map((k) => ({ d: k, n: D.day[k].n, c: D.day[k].c, h: D.day[k].h || 0 })), mocks: D.mk.slice(-12), wrong: D.wr.slice(-30).map((w) => ({ unit: w.id, q: w.q, n: w.n, ok: w.ok, due: w.due })),
      badges: Object.entries(D.stk).map(([id, d]) => ({ id, d })), dq: Object.keys(D.dq).length, dqOk: Object.keys(D.dq).filter((k) => D.dq[k].ok).length, misconceptions: dg.results || [] };
  },

  /* ===== 老師後台：資料管理（名單、題庫、設定、圖片） ===== */
  "GET /api/admin/roster": async (req, env) => {
    const { user } = await teacher(req, env);
    return { rows: mem.rosterRows.filter((x) => user.admin || (x.role === "student" && ownsClass(user, x.class))).sort((a, b) => String(a.class).localeCompare(String(b.class)) || a.no - b.no), legacy: mem.legacy, me: user.email };
  },
  "POST /api/admin/roster": async (req, env) => {
    const { user } = await teacher(req, env), b = await body(req, 200000);
    const rows = (Array.isArray(b.rows) ? b.rows : []).slice(0, 500).map((x, i) => ({ _row: i + 1, email: String(x.email || "").trim().toLowerCase(), class: String(x.class ?? "").trim(), no: String(x.no ?? "").trim(), name: String(x.name ?? "").trim(), role: String(x.role || "student").trim(), grade: String(x.grade ?? "6").trim(), active: x.active === "0" || x.active === 0 ? "0" : "1", expires: String(x.expires ?? "").trim(), _hasExp: x.expires !== undefined && x.expires !== null }));
    if (!rows.length) throw bad("empty");
    const chk = checkRoster(rows, { partial: true }), errs = [...chk.errs];
    const have = (await env.DB.prepare("SELECT email,class,no FROM roster WHERE role='student' AND active!='0'").all()).results, mine = new Set(chk.out.map((x) => x.email));
    chk.out.forEach((x) => { if (x.role === "student" && x.active !== "0" && have.some((h) => h.class === x.class && h.no === x.no && !mine.has(h.email))) errs.push(`${x.class} 班 ${x.no} 號已經有人了（${x.email}）`); });
    const hasExp = new Set(rows.filter((x) => x._hasExp).map((x) => x.email)), self = chk.out.find((x) => normEmail(x.email) === normEmail(user.email));
    if (self && (user.admin ? self.role !== "admin" : self.role !== "teacher") || self && self.active === "0") errs.push("不能把自己降級或停用，否則你會進不了後台");
    if (!user.admin) {
      /* 老師：只能新增或修改自己班的學生，不能碰老師、管理員，也不能換到別班 */
      const cur = (await authed(req, env)).roster;
      chk.out.forEach((x) => { if (x.role !== "student" || !ownsClass(user, x.class) || (cur.has(normEmail(x.email)) && !canTouch(user, cur.get(normEmail(x.email))))) errs.push(`${x.email}：你只能管理自己班的學生`); });
    }
    if (errs.length) return { ok: false, errs };
    await env.DB.batch(chk.out.map((x) => env.DB.prepare("INSERT INTO roster(email,class,no,name,role,grade,active,expires) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(email) DO UPDATE SET class=excluded.class,no=excluded.no,name=excluded.name,role=excluded.role,grade=excluded.grade,active=excluded.active,expires=CASE WHEN ?=1 THEN excluded.expires ELSE roster.expires END").bind(x.email, x.class, x.no, x.name, x.role, x.grade, x.active, x.expires || "", hasExp.has(x.email) ? 1 : 0)));
    await bump(env); return { ok: true, n: chk.out.length };
  },
  /* 一次設定整班（或指定幾位）的授權到期日；date 留空＝不限期 */
  "POST /api/admin/roster/expire": async (req, env) => {
    const { user, roster } = await teacher(req, env); const b = await body(req), date = String(b.date || "").trim();
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw bad("bad_date");
    const emails = (Array.isArray(b.emails) ? b.emails : []).slice(0, 500).map((x) => String(x).toLowerCase());
    emails.forEach((e) => { if (!canTouch(user, roster.get(normEmail(e)))) throw bad("forbidden", 403); });
    if (b.cls) needClass(user, String(b.cls));
    if (emails.length) await env.DB.batch(emails.map((e) => env.DB.prepare("UPDATE roster SET expires=? WHERE email=? AND role<>'admin'").bind(date, e)));
    else if (b.cls) await env.DB.prepare("UPDATE roster SET expires=? WHERE class=? AND role='student'").bind(date, String(b.cls)).run();
    else throw bad("empty");
    await bump(env); return { ok: true };
  },
  "POST /api/admin/roster/delete": async (req, env) => {
    const { user, roster } = await teacher(req, env), b = await body(req), email = String(b.email || "").toLowerCase();
    if (normEmail(email) === normEmail(user.email)) throw bad("cannot_delete_self");
    if (!canTouch(user, roster.get(normEmail(email)))) throw bad("forbidden", 403);
    await env.DB.prepare("DELETE FROM roster WHERE email=?").bind(email).run(); await bump(env); return { ok: true };
  },
  "GET /api/admin/bank": async (req, env) => {
    await teacher(req, env); return { rows: mem.bank, legacy: mem.legacy };
  },
  "POST /api/admin/bank": async (req, env) => {
    await adminOnly(req, env); const b = await body(req, 900000);
    const rows = (Array.isArray(b.rows) ? b.rows : []).slice(0, 2000).map((x, i) => {
      const o = { _row: i + 1 }; for (const k of ["id", "unit", "type", "lv", "q", "options", "answer", "hint", "diag", "img", "himg", "print", "daily", "mock", "active"]) o[k] = String(x[k] ?? "").trim();
      if (!o.id) o.id = (o.unit || "x") + "-" + crypto.randomUUID().slice(0, 5);
      return o;
    });
    if (!rows.length) throw bad("empty");
    const chk = checkBank(rows); if (chk.errs.length) return { ok: false, errs: chk.errs };
    const mode = b.mode === "replace" ? "replace" : "merge", now = Date.now();
    const ins = chk.out.map((x) => env.DB.prepare("INSERT INTO bank(id,unit,type,lv,q,options,answer,hint,diag,img,himg,print,daily,mock,active,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET unit=excluded.unit,type=excluded.type,lv=excluded.lv,q=excluded.q,options=excluded.options,answer=excluded.answer,hint=excluded.hint,diag=excluded.diag,img=excluded.img,himg=excluded.himg,print=excluded.print,daily=excluded.daily,mock=excluded.mock,active=excluded.active,updated=excluded.updated")
      .bind(x.id, x.unit, x.type, x.lv, x.q, x.options, x.answer, x.hint, x.diag, x.img, x.himg, x.print, x.daily, x.mock, x.active, now));
    if (mode === "replace") await env.DB.prepare("DELETE FROM bank").run();
    for (let i = 0; i < ins.length; i += 40) await env.DB.batch(ins.slice(i, i + 40));
    await bump(env); return { ok: true, n: chk.out.length, ids: chk.out.map((x) => x.id) };
  },
  "POST /api/admin/bank/delete": async (req, env) => {
    await adminOnly(req, env); const b = await body(req), ids = (Array.isArray(b.ids) ? b.ids : []).slice(0, 500).map(String);
    for (let i = 0; i < ids.length; i += 40) await env.DB.batch(ids.slice(i, i + 40).map((id) => env.DB.prepare("DELETE FROM bank WHERE id=?").bind(id)));
    await bump(env); return { ok: true, n: ids.length };
  },
  "GET /api/admin/settings": async (req, env) => {
    await teacher(req, env); const c = CFG(env);
    return { settings: mem.settings, effective: { step: c.step, pts: c.pts, capQ: c.capQ, capMock: c.capMock, review: c.review, hint: c.hint } };
  },
  "POST /api/admin/settings": async (req, env) => {
    await adminOnly(req, env); const b = await body(req), out = {};
    const list = (v) => String(v ?? "").split(",").map((x) => x.trim()).filter(Boolean);
    const num = (k, min, max) => { if (b[k] === undefined || b[k] === "") return; const n = +b[k]; if (!Number.isFinite(n) || n < min || n > max) throw bad("bad_" + k); out[k] = String(n); };
    if (b.POINTS_BY_LEVEL !== undefined && b.POINTS_BY_LEVEL !== "") { const a = list(b.POINTS_BY_LEVEL).map(Number); if (a.length !== 3 || a.some((x) => !Number.isFinite(x) || x < 1 || x > 1000)) throw bad("bad_POINTS_BY_LEVEL"); out.POINTS_BY_LEVEL = a.join(","); }
    if (b.REVIEW_DAYS !== undefined && b.REVIEW_DAYS !== "") { const a = list(b.REVIEW_DAYS).map(Number); if (!a.length || a.length > 6 || a.some((x) => !Number.isInteger(x) || x < 1 || x > 90)) throw bad("bad_REVIEW_DAYS"); out.REVIEW_DAYS = a.join(","); }
    num("LEVEL_STEP", 10, 100000); num("HINT_COST", 0, 100); num("DAILY_Q_CAP", 10, 5000); num("DAILY_MOCK_CAP", 0, 50);
    await env.DB.prepare("INSERT INTO settings(k,v) VALUES('cfg',?) ON CONFLICT(k) DO UPDATE SET v=excluded.v").bind(JSON.stringify(out)).run(); await bump(env); return { ok: true };
  },
  /* 題目附圖上傳（前端會先縮到 1000px 以內再傳；存在 D1，不需要額外儲存服務） */
  "POST /api/admin/image": async (req, env) => {
    await adminOnly(req, env); const b = await body(req, 700000);
    if (!["image/png", "image/jpeg", "image/webp", "image/gif"].includes(b.mime)) throw bad("bad_mime");
    const b64 = String(b.b64 || ""); if (!/^[A-Za-z0-9+/=]+$/.test(b64) || b64.length > 560000) throw bad("image_too_big");
    const id = [...crypto.getRandomValues(new Uint8Array(8))].map((x) => x.toString(16).padStart(2, "0")).join("");
    await env.DB.prepare("INSERT INTO images(id,mime,data,size,created) VALUES(?,?,?,?,?)").bind(id, b.mime, b64, Math.floor(b64.length * 0.75), Date.now()).run();
    return { ok: true, ref: "d:" + id };
  },
  /* 把舊的資料（Google 試算表同步到 KV 的名單與題庫）一次搬進 D1，之後就只在老師後台管理 */
  "POST /api/admin/migrate": async (req, env) => {
    await adminOnly(req, env); if (!env.KV) throw bad("no_kv");
    const [b, r] = await Promise.all([env.KV.get("bank", "json"), env.KV.get("roster", "json")]);
    const st = [];
    (r || []).forEach((x) => st.push(env.DB.prepare("INSERT OR IGNORE INTO roster(email,class,no,name,role,grade,active) VALUES(?,?,?,?,?,?,?)").bind(String(x.email).toLowerCase(), String(x.class), +x.no || 0, x.name || "", x.role || "student", +x.grade || 6, x.active === "0" ? "0" : "1")));
    (b || []).forEach((x) => st.push(env.DB.prepare("INSERT OR IGNORE INTO bank(id,unit,type,lv,q,options,answer,hint,diag,img,himg,print,daily,mock,active,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(x.id, x.unit, x.type, +x.lv || 2, x.q, x.options || "", String(x.answer), x.hint || "", x.diag || "", x.img || "", x.himg || "", x.print || "", x.daily || "", x.mock === "0" ? "0" : "1", x.active === "0" ? "0" : "1", Date.now())));
    for (let i = 0; i < st.length; i += 40) await env.DB.batch(st.slice(i, i + 40));
    await bump(env); return { ok: true, roster: (r || []).length, bank: (b || []).length };
  },

  /* 老師：重設或刪除學生資料（學期結束、轉班、家長要求刪除個資）
     mode=reset  只清空成績與錯題，保留帳號
     mode=delete 刪除該學生的所有資料（成績、作答紀錄、作答階段）
     mode=class  刪除整個班級所有學生的資料
     名單（試算表）要另外把該列刪除或 active 改 0，否則他下次登入會重新建立空白資料 */
  "POST /api/admin/delete": async (req, env) => {
    const { user, roster } = await authed(req, env);
    if (user.role !== "teacher") throw bad("forbidden", 403);
    const b = await body(req), cls = String(b.cls || ""), mode = String(b.mode || "");
    if (!["reset", "delete", "class"].includes(mode) || !cls) throw bad("bad_request");
    needClass(user, cls);
    if (mode === "class") {
      const emails = (await env.DB.prepare("SELECT email FROM profiles WHERE cls=? AND role='student'").bind(cls).all()).results.map((x) => x.email);
      for (const e of emails) await env.DB.batch([env.DB.prepare("DELETE FROM attempts WHERE email=?").bind(e), env.DB.prepare("DELETE FROM sessions WHERE email=?").bind(e), env.DB.prepare("DELETE FROM profiles WHERE email=?").bind(e)]);
      return { ok: true, deleted: emails.length };
    }
    const row = await env.DB.prepare("SELECT email FROM profiles WHERE cls=? AND no=? AND role='student'").bind(cls, +b.no).first();
    if (!row) throw bad("no_student", 404);
    if (mode === "reset") await env.DB.batch([env.DB.prepare("UPDATE profiles SET data=?, updated=? WHERE email=?").bind(JSON.stringify(blank()), Date.now(), row.email), env.DB.prepare("DELETE FROM attempts WHERE email=?").bind(row.email), env.DB.prepare("DELETE FROM sessions WHERE email=?").bind(row.email)]);
    else await env.DB.batch([env.DB.prepare("DELETE FROM attempts WHERE email=?").bind(row.email), env.DB.prepare("DELETE FROM sessions WHERE email=?").bind(row.email), env.DB.prepare("DELETE FROM profiles WHERE email=?").bind(row.email)]);
    return { ok: true };
  },
};

export async function handle(req, env) {
  const h = corsHeaders(req, env), url = new URL(req.url);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: h });
  const im = /^\/api\/img\/([a-f0-9]{16})$/.exec(url.pathname);
  if (im && req.method === "GET") { // 題目附圖：網址不可猜，公開讀取（<img> 無法帶登入資訊）
    const r = await env.DB.prepare("SELECT mime,data FROM images WHERE id=?").bind(im[1]).first();
    if (!r) return out({ err: "not_found" }, 404, h);
    return new Response(Uint8Array.from(atob(r.data), (c) => c.charCodeAt(0)), { headers: { "Content-Type": r.mime, "Cache-Control": "public, max-age=86400", "X-Content-Type-Options": "nosniff", "Cross-Origin-Resource-Policy": "cross-origin" } });
  }
  const fn = routes[req.method + " " + url.pathname];
  if (!fn) return out({ err: "not_found" }, 404, h);
  try { return out(await fn(req, env), 200, h); }
  catch (e) {
    if (e instanceof HttpError) return out({ err: e.code }, e.status, h);
    console.error(e && e.stack || e);
    return out({ err: "server" }, 500, h);
  }
}
export default { fetch: (req, env) => handle(req, env) };
