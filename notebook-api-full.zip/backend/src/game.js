/* 積分、貼紙、錯題本（間隔複習）、連續天數：全部在伺服器計算，前端只負責顯示 */

export const TZ_HOURS = 8; // 台灣時間
export function ymd(ms = Date.now()) {
  const d = new Date(ms + TZ_HOURS * 3600e3);
  return d.getUTCFullYear() + "-" + String(d.getUTCMonth() + 1).padStart(2, "0") + "-" + String(d.getUTCDate()).padStart(2, "0");
}
export function addDays(t, n) { const d = new Date(t + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }

/* ---- 可調整的難易度設定（wrangler.toml 的 [vars] 可覆蓋；沒設就用預設） ----
   POINTS_BY_LEVEL  答對一題的積分，依題目難度 1/2/3，例如 "10,15,20"
   LEVEL_STEP       每幾分升一級（越大越難升級）
   DAILY_Q_CAP      每天最多幾題計分（防刷）
   DAILY_MOCK_CAP   每天前幾份模擬卷有獎勵
   REVIEW_DAYS      錯題複習間隔（天），例如 "1,3,7"，全部答對才畢業
   HINT_COST        看一次提示扣幾分（0 = 不扣）；看過提示的題目答對只拿一半積分 */
export function cfgOf(env = {}) {
  const nums = (s, def) => { const a = String(s || "").split(",").map((x) => +x.trim()); return a.length && a.every((x) => Number.isFinite(x) && x > 0) ? a : def; };
  const pts = nums(env.POINTS_BY_LEVEL, [10, 15, 20]); while (pts.length < 3) pts.push(pts[pts.length - 1]);
  return { pts, step: Math.max(10, +env.LEVEL_STEP || 150), capQ: Math.max(10, +env.DAILY_Q_CAP || 100), capMock: Math.max(0, env.DAILY_MOCK_CAP === undefined || env.DAILY_MOCK_CAP === "" ? 3 : +env.DAILY_MOCK_CAP), review: nums(env.REVIEW_DAYS, [1, 3, 7]), hint: env.HINT_COST === undefined || env.HINT_COST === "" || !Number.isFinite(+env.HINT_COST) ? 3 : Math.min(100, Math.max(0, Math.floor(+env.HINT_COST))) };
}
export const DEFAULT = cfgOf({});

export const blank = () => ({ pts: 0, u: {}, day: {}, wr: [], stk: {}, dq: {}, mk: [], sk: { last: "", n: 0 }, pf: 0, fx: 0, hard: 0, hn: 0, dn: 0, ex: { early: 0, wend: 0 }, mkn: 0, m80n: 0, m100n: 0, cap: { d: "", n: 0, mk: 0 } });
export const norm = (d) => Object.assign(blank(), d || {});

function cap(D, t) { if (D.cap.d !== t) D.cap = { d: t, n: 0, mk: 0 }; return D.cap; }
export const overCap = (D, c = DEFAULT, t = ymd()) => D.cap.d === t && D.cap.n > c.capQ;

export const tot = (D) => { let n = 0, c = 0; for (const k in D.u) { n += D.u[k].n; c += D.u[k].c; } return { n, c }; };
export const lv = (D, c = DEFAULT) => Math.floor(D.pts / c.step) + 1;
export const seen = (D) => Object.keys(D.u).filter((k) => D.u[k].seen).length;
const dqOk = (D) => Object.keys(D.dq).filter((k) => D.dq[k].ok).length;
const units = (D, minN, minAcc) => Object.values(D.u).filter((x) => x.n >= minN && x.c / x.n >= minAcc).length;

/* ---- 貼紙（勳章）----
   每一類（family）有一串里程碑，越後面越難、階級（tier 1~5：銅銀金白金鑽）越高。
   id 規則：<類別代號><里程碑>，例如 c100＝累積答對 100 題。g 是 24×24 的線條圖示路徑。
   要新增一類或一個里程碑，只要改下面的 FAMS 就好。 */
const G = {
  star: "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z", flame: "M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z",
  cal: "M4 5h16v15H4zM4 10h16M9 15l2 2 4-4M8 3v4M16 3v4", sunrise: "M3 18h18M7 18a5 5 0 0 1 10 0M12 4v3M5 8l2 2M19 8l-2 2", week: "M4 7h16v13H4zM4 11h16M8 3v4M16 3v4M9 15h.01M12 15h.01M15 15h.01",
  target: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM12 12h.01", sun: "M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2",
  paper: "M6 3h9l4 4v14H6zM15 3v4h4M9 12h6M9 16h6", flag: "M5 21V3M5 4h12l-2 4 2 4H5", medal: "M12 15a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM8.5 14L7 22l5-3 5 3-1.5-8",
  heart: "M12 20S4 15 4 9.5A4.2 4.2 0 0 1 12 8a4.2 4.2 0 0 1 8 1.5C20 15 12 20 12 20z", mount: "M3 20l6-11 4 7 3-5 5 9z", compass: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM15.5 8.5l-2 5-5 2 2-5z",
  coin: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v10M9 9.5h4.5a1.5 1.5 0 0 1 0 3h-3a1.5 1.5 0 0 0 0 3H15", gem: "M6 4h12l4 6-10 11L2 10zM2 10h20", book: "M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM4 19V5M9 8h6",
  hex: "M12 3l8 4.5v9L12 21l-8-4.5v-9z", bolt: "M13 2L4 14h7l-1 8 9-12h-7z", cap: "M12 3l9 5-9 5-9-5zM7 11v5c0 1.5 2.5 3 5 3s5-1.5 5-3v-5", trophy: "M8 4h8v5a4 4 0 0 1-8 0zM8 6H4v2a3 3 0 0 0 3 3M16 6h4v2a3 3 0 0 1-3 3M12 13v4M8 21h8M10 17h4",
  check: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM8 12l3 3 5-6", crown: "M3 18h18M5 18L3 8l5 4 4-7 4 7 5-4-2 10", chart: "M3 20h18M6 20v-7M11 20V8M16 20v-5M21 20V5", broom: "M14 4l6 6M12 6l6 6-8 8H4v-6zM8 14l4 4",
};
const gradeUnits = (D, g) => Object.keys(D.u).filter((k) => k[0] === String(g)).reduce((a, k) => a + D.u[k].c, 0);
const stkCount = (D) => Object.keys(D.stk).filter((k) => !/^col\d/.test(k)).length;
const accPct = (D) => { const t = tot(D); return t.n >= 100 ? Math.floor((t.c / t.n) * 100) : 0; };
const maxDay = (D) => Math.max(0, ...Object.values(D.day).map((x) => x.n));
export const FAMS = [
  { k: "c", cat: "練習量", g: G.star, ms: [10, 25, 50, 100, 200, 300, 500, 750, 1000, 1500, 2000, 3000, 5000], names: ["十題達人", "二十五題小將", "五十題勇士", "百題王者", "兩百題大師", "三百題精英", "五百題傳奇", "七百五十題名將", "千題宗師", "千五巨擘", "兩千題鬥士", "三千題巨匠", "五千題神話"], d: (m) => `累積答對 ${m} 題`, v: (D) => tot(D).c },
  { k: "sp", cat: "練習量", g: G.bolt, ms: [15, 30, 50, 75, 100], names: ["小試牛刀", "單日衝刺", "五十題衝刺", "七十五題衝刺", "百題狂奔"], d: (m) => `一天內答 ${m} 題`, v: maxDay },
  { k: "acc", cat: "練習量", g: G.check, ms: [80, 90, 95], names: ["穩穩的準", "神準", "百步穿楊"], d: (m) => `答過 100 題以上，答對率達 ${m}%`, v: accPct },
  { k: "s", cat: "習慣", g: G.flame, ms: [3, 5, 7, 10, 14, 21, 30, 45, 60, 90, 100, 180, 365], names: ["小火苗", "五日不輟", "持之以恆", "十日精進", "兩週不間斷", "三週達人", "月月精進", "四十五日毅力", "雙月勇者", "一季堅持", "百日築基", "半年長跑", "全年無休"], d: (m) => `連續 ${m} 天練習`, v: (D) => D.sk.n },
  { k: "dn", cat: "習慣", g: G.cal, ms: [5, 10, 20, 30, 50, 75, 100, 150, 200, 300], names: ["練習五日", "練習十日", "練習二十日", "練習三十日", "練習五十日", "練習七十五日", "練習百日", "練習一百五十日", "練習兩百日", "練習三百日"], d: (m) => `累積練習 ${m} 天`, v: (D) => D.dn },
  { k: "eb", cat: "習慣", g: G.sunrise, ms: [1, 5, 10, 25, 50], names: ["早起的鳥兒", "晨間習慣", "晨型人", "清晨常客", "晨光守護者"], d: (m) => `早上 7 點前練習 ${m} 天`, v: (D) => D.ex.early },
  { k: "we", cat: "習慣", g: G.week, ms: [1, 4, 10, 25], names: ["假日也學習", "週末學徒", "週末戰士", "週末王者"], d: (m) => `週末練習 ${m} 天`, v: (D) => D.ex.wend },
  { k: "dq", cat: "每日一題", g: G.sun, ms: [1, 3, 5, 10, 20, 30, 50, 75, 100, 150, 200, 365], names: ["日課起步", "三日小達人", "每日小太陽", "每日習慣", "二十日成就", "三十日挑戰", "五十日恆心", "七十五日堅持", "百日一題", "一百五十日", "兩百日", "年度全勤"], d: (m) => `每日一題答對 ${m} 次`, v: dqOk },
  { k: "p", cat: "小測驗", g: G.target, ms: [1, 3, 5, 10, 20, 30, 50, 100], names: ["百發百中", "神射手", "連珠妙手", "完美主義者", "二十度全壘打", "三十度滿分", "五十度無懈可擊", "百次完美"], d: (m) => `小測驗（5 題以上）全對 ${m} 次`, v: (D) => D.pf },
  { k: "mk", cat: "模擬卷", g: G.paper, ms: [1, 3, 5, 10, 20, 30, 50], names: ["初次上場", "三戰成名", "模擬卷常客", "十場老手", "二十場戰將", "三十場統帥", "五十場傳說"], d: (m) => `完成 ${m} 份模擬卷`, v: (D) => Math.max(D.mkn, D.mk.length) },
  { k: "m8", cat: "模擬卷", g: G.flag, ms: [1, 3, 5, 10, 20, 30], names: ["高分新手", "高分三連", "模擬卷高手", "高分常勝軍", "二十場高分", "三十場高分"], d: (m) => `模擬卷 80 分以上 ${m} 次`, v: (D) => Math.max(D.m80n, D.mk.filter((x) => x.sc >= 80).length) },
  { k: "m1", cat: "模擬卷", g: G.medal, ms: [1, 3, 5, 10], names: ["滿分模擬", "三度滿分", "五度滿分", "十度滿分"], d: (m) => `模擬卷 100 分 ${m} 次`, v: (D) => Math.max(D.m100n, D.mk.filter((x) => x.sc >= 100).length) },
  { k: "fx", cat: "錯題", g: G.heart, ms: [1, 3, 5, 10, 20, 30, 50, 75, 100, 150], names: ["初次畢業", "三題畢業", "錯題終結者", "錯題清道夫", "二十題畢業", "金鐘罩", "五十題畢業", "七十五題畢業", "百題畢業", "錯題剋星"], d: (m) => `錯題複習畢業 ${m} 題`, v: (D) => D.fx },
  { k: "hd", cat: "挑戰", g: G.mount, ms: [1, 5, 10, 25, 50, 100, 200, 300, 500], names: ["挑戰起步", "五戰五勝", "勇於挑戰", "挑戰達人", "登頂者", "百座山頭", "兩百座山頭", "三百座山頭", "攻頂之王"], d: (m) => `答對 ${m} 題挑戰題`, v: (D) => D.hard },
  { k: "ex", cat: "探索", g: G.compass, ms: [3, 5, 10, 15, 20, 30, 40, 60, 80], names: ["初探單元", "單元探險家", "地圖收集者", "十五站旅人", "數學旅行家", "三十站遠征", "四十站冒險", "六十站行者", "八十站環遊"], d: (m) => `逛過 ${m} 個單元`, v: seen },
  { k: "ms", cat: "精熟", g: G.book, ms: [1, 3, 5, 10, 15], names: ["單元達人", "三科達人", "五科達人", "十科達人", "十五科達人"], d: (m) => `${m} 個單元答 20 題以上且答對率 90%`, v: (D) => units(D, 20, 0.9) },
  { k: "ar", cat: "精熟", g: G.hex, ms: [3, 5, 10, 15], names: ["三項全能", "全能選手", "十項全能", "十五項全能"], d: (m) => `${m} 個單元各答 5 題以上、答對率 80%`, v: (D) => units(D, 5, 0.8) },
  ...[1, 2, 3, 4, 5, 6].map((g) => ({ k: "g" + g, cat: "年級", g: G.cap, ms: [30, 100, 300, 600], names: ["新手", "好手", "高手", "大師"].map((x) => "一二三四五六"[g - 1] + "年級" + x), d: (m) => `${"一二三四五六"[g - 1]}年級單元答對 ${m} 題`, v: (D) => gradeUnits(D, g) })),
  { k: "pts", cat: "成長", g: G.coin, ms: [100, 250, 500, 1000, 2000, 3000, 5000, 7500, 10000, 15000, 20000], names: ["百分新手", "二百五十分", "五百分", "千分俱樂部", "兩千分", "三千分", "五千分", "七千五百分", "萬分達人", "一萬五千分", "兩萬分傳奇"], d: (m) => `累積 ${m} 積分`, v: (D) => D.pts },
  { k: "lv", cat: "成長", g: G.gem, ms: [3, 5, 7, 10, 15, 20, 30, 40, 50], names: ["升級在望", "閃亮新星", "七星連珠", "星光閃耀", "十五級行家", "數學大師", "三十級宗師", "四十級泰斗", "五十級至尊"], d: (m) => `升到 Lv.${m}`, v: (D, c) => lv(D, c) },
  { k: "col", cat: "收藏", g: G.trophy, ms: [10, 25, 50, 75, 100, 150], names: ["貼紙新手", "貼紙玩家", "貼紙收藏家", "貼紙大亨", "百張收藏", "貼紙之王"], d: (m) => `收集 ${m} 張貼紙`, v: stkCount },
];
const TIER_PTS = [10, 20, 30, 50, 80]; // 銅、銀、金、白金、鑽石 解鎖時獲得的積分
export const STK = [];
for (const f of FAMS) f.ms.forEach((m, i) => STK.push({ id: f.k + m, f: f.k, cat: f.cat, t: 1 + Math.floor((i * 5) / f.ms.length), m, n: f.names[i], d: f.d(m), g: f.g, ok: (D, c) => f.v(D, c) >= m }));
STK.push(
  { id: "first", f: "x", cat: "特別", t: 1, m: 1, n: "初試啼聲", d: "完成第一次練習", g: G.star, ok: (D) => tot(D).n >= 1 },
  { id: "steady", f: "x", cat: "特別", t: 3, m: 1, n: "穩定發揮", d: "連續 3 份模擬卷 80 分以上", g: G.chart, ok: (D) => D.mk.length >= 3 && D.mk.slice(-3).every((x) => x.sc >= 80) },
  { id: "clean", f: "x", cat: "特別", t: 3, m: 1, n: "錯題本清空", d: "答過 30 題以上、畢業 3 題以上，且錯題本清空", g: G.broom, ok: (D) => D.wr.length === 0 && D.fx >= 3 && tot(D).n >= 30 },
);
export const STK_PUBLIC = STK.map(({ id, f, cat, t, m, n, d, g }) => ({ id, f, cat, t, m, n, d, g }));
/* 每一類下一張要拿的貼紙與進度（給前端畫進度條） */
export function stkProgress(D, c = DEFAULT) {
  const out = {};
  for (const f of FAMS) { const i = f.ms.findIndex((m) => !D.stk[f.k + m]); if (i >= 0) out[f.k] = { id: f.k + f.ms[i], cur: Math.min(f.v(D, c), f.ms[i]), target: f.ms[i] }; }
  return out;
}

/* 記錄一題。回傳是否有計分。
   積分依題目難度 lv：預設 10／15／20 */
export function rec(D, q, ok, wrongMode, c = DEFAULT, t = ymd(), noPts = false, mult = 1) {
  const id = q.unit, k = id + "|" + q.q, cp = cap(D, t), scored = cp.n < c.capQ, lvq = [1, 2, 3].includes(q.lv) ? q.lv : 2;
  const u = (D.u[id] = D.u[id] || { n: 0, c: 0 }), d = (D.day[t] = D.day[t] || { n: 0, c: 0 }), w = D.wr.find((x) => x.k === k);
  u.n++; d.n++; cp.n++;
  if (ok) {
    u.c++; d.c++;
    if (scored && !noPts) { D.pts += Math.floor(c.pts[(w && wrongMode ? w.lv || lvq : lvq) - 1] * mult); if (lvq === 3) D.hard++; }
    if (w && wrongMode) {
      w.ok = (w.ok || 0) + 1;
      if (w.ok >= c.review.length) { D.wr.splice(D.wr.indexOf(w), 1); D.fx++; D.pts += 15; }
      else w.due = addDays(t, c.review[w.ok - 1]); // 答對一次：隔 1 天、再答對隔 3 天、再答對隔 7 天，全部通過才畢業
    }
  } else if (w) { w.ok = 0; w.n++; w.due = addDays(t, 1); }
  else {
    D.wr.push({ k, id, q: q.q, a: q.a, o: q.o, t: q.t, alt: q.alt, h: q.h, img: q.img, himg: q.himg, lv: lvq, n: 1, ok: 0, at: t, due: t });
    if (D.wr.length > 200) D.wr.shift();
  }
  const keys = Object.keys(D.day).sort();
  while (keys.length > 21) delete D.day[keys.shift()];
  return scored;
}
/* 看提示：扣分（不會扣到負數），並記錄次數（老師後台可以看到誰很常看提示） */
export function hintUsed(D, c = DEFAULT, t = ymd()) {
  const d = (D.day[t] = D.day[t] || { n: 0, c: 0 }), cost = Math.min(D.pts, c.hint);
  D.pts -= cost; D.hn = (D.hn || 0) + 1; d.h = (d.h || 0) + 1;
  return cost;
}
export const dueList = (D, t = ymd()) => D.wr.filter((w) => !w.due || w.due <= t);

export function touchDay(D, t = ymd(), now = Date.now()) {
  const y = ymd(now - 864e5);
  if (D.sk.last === t) return;
  D.sk.n = D.sk.last === y ? D.sk.n + 1 : 1; D.sk.last = t;
  if (D.sk.n > 1) D.pts += Math.min(D.sk.n, 7) * 2;
  const tw = new Date(now + TZ_HOURS * 3600e3); D.dn++;
  if (tw.getUTCHours() < 7) D.ex.early++;
  if (tw.getUTCDay() === 0 || tw.getUTCDay() === 6) D.ex.wend++;
}

export function award(D, c = DEFAULT, t = ymd()) {
  const got = []; let again = true;
  while (again) { again = false; for (const s of STK) if (!D.stk[s.id] && s.ok(D, c)) { D.stk[s.id] = t; D.pts += TIER_PTS[s.t - 1]; got.push(s.id); again = true; } } // 貼紙加分可能再解鎖等級貼紙
  return got;
}

/* 模擬卷獎勵（每天前幾份） */
export function mockBonus(D, sc, c = DEFAULT, t = ymd(), small = false) {
  if (small) return; // 題數太少的自選練習卷不算模擬卷（不發獎勵、不計入勳章）
  const cp = cap(D, t);
  D.mk.push({ d: t, sc }); if (D.mk.length > 30) D.mk.shift();
  D.mkn++; if (sc >= 80) D.m80n++; if (sc >= 100) D.m100n++;
  if (cp.mk < c.capMock) { cp.mk++; D.pts += 20 + (sc >= 80 ? 50 : 0); }
}
