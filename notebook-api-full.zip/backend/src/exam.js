/* 組卷：小測驗、模擬卷（細目表）、每日一題。答案只留在伺服器。 */
import { GENS, GEN_IDS, runGen, gradeOf, shuffle, ri, rng, key } from "./gen.js";

/* ---- 固定題庫（來自 Google 試算表）轉成內部題目 ---- */
/* 文字題的答案比對：全形轉半形、轉小寫、去掉所有空白與引號括號、去掉句尾標點。
   不會動到中間的 . : , / 等符號，所以 0.5、3:2、3/4 不會被誤判成別的答案。 */
export const normText = (s) => String(s ?? "").normalize("NFKC").toLowerCase().replace(/[\s\u3000"'“”‘’「」『』()（）]/g, "").replace(/[。.!！?？]+$/, "").slice(0, 80);

export function parseDiag(s, type) {
  const d = {};
  String(s || "").split(";;").forEach((p) => {
    const i = p.indexOf("=>");
    if (i < 1) return;
    const k = p.slice(0, i).trim(), v = p.slice(i + 2).trim();
    if (k && v) d[type === "num" ? key(k) : type === "text" ? normText(k) : k] = v;
  });
  return d;
}
export function fixedToQ(row) {
  const o = row.type === "choice" ? String(row.options || "").split("|").map((s) => s.trim()).filter(Boolean) : null;
  const alt = row.type === "text" ? String(row.answer).split("|").map((s) => s.trim()).filter(Boolean) : null; // 文字題：answer 可用 | 放多個可接受的答案
  return { unit: row.unit, qid: row.id, q: row.q, o, t: alt ? "text" : undefined, alt: alt || undefined, a: row.type === "num" ? +row.answer : alt ? alt[0] : String(row.answer), h: row.hint || "", d: parseDiag(row.diag, row.type), lv: +row.lv || 2, img: row.img || "", himg: row.himg || "", print: row.print !== "0" && row.print !== 0, mock: row.mock !== "0" && row.mock !== 0, daily: row.daily === "1" || row.daily === 1 };
}
const fixedFor = (bank, pred) => bank.filter((r) => r.active !== "0" && r.active !== 0 && pred(r)).map(fixedToQ);

export const LETTERS = "ABCDEFGH";
export const letterOf = (q) => (q.o ? LETTERS[q.o.indexOf(String(q.a))] || "" : "");
function finalize(q, r) { if (q.o) q.o = shuffle(q.o, r); return q; }

/* ---- 小測驗：單元產生器 5 題＋固定題 2 題；沒有產生器就用固定題最多 5 題 ---- */
export function buildQuiz(unit, bank, r) {
  const fx = shuffle(fixedFor(bank, (x) => x.unit === unit), r), out = [], seen = new Set();
  const add = (q) => { if (q && !seen.has(q.q)) { seen.add(q.q); out.push(finalize(q, r)); return true; } return false; };
  if (GEN_IDS.has(unit)) {
    for (let i = 0; out.length < 5 && i < 40; i++) add(runGen(unit, r));
    fx.slice(0, 2).forEach(add);
  } else fx.slice(0, 5).forEach(add);
  return out;
}

/* ---- 模擬卷：雙向細目表。難度 3:5:2，同一單元最多 2 題，由易到難 ---- */
export function mockPool(grade, bank) {
  let units = GENS.filter((g) => gradeOf(g.id) <= grade && gradeOf(g.id) >= grade - 1);
  if (units.length < 3) units = GENS.filter((g) => gradeOf(g.id) <= grade);
  const ok = new Set(units.map((g) => g.id));
  const cands = units.map((g) => ({ kind: "gen", unit: g.id, lv: g.lv }));
  fixedFor(bank, (x) => gradeOf(x.unit) <= grade && gradeOf(x.unit) >= grade - 1 && x.mock !== "0" && x.mock !== 0).forEach((q) => cands.push({ kind: "fix", unit: q.unit, lv: q.lv, q }));
  return { cands, units: ok };
}
export function buildMock(grade, bank, r, n = 10, units = null) {
  const pick = units && units.length ? new Set(units) : null;
  let { cands } = mockPool(grade, bank);
  if (pick) {
    cands = [...pick].filter((u) => GEN_IDS.has(u)).map((u) => ({ kind: "gen", unit: u, lv: GENS.find((g) => g.id === u).lv }));
    fixedFor(bank, (x) => pick.has(x.unit) && x.mock !== "0" && x.mock !== 0).forEach((q) => cands.push({ kind: "fix", unit: q.unit, lv: q.lv, q }));
  }
  const c1 = Math.round(n * 0.3), c3 = Math.round(n * 0.2), plan = [[3, c3], [2, n - c1 - c3], [1, c1]];
  const out = [], seen = new Set(), per = {}, perMax = pick ? Math.max(2, Math.ceil(n / pick.size)) : 2;
  const tryAdd = (c, maxPer) => {
    if ((per[c.unit] || 0) >= maxPer) return false;
    const q = c.kind === "gen" ? runGen(c.unit, r) : { ...c.q };
    if (!q || seen.has(q.q)) return false;
    seen.add(q.q); per[c.unit] = (per[c.unit] || 0) + 1; out.push(finalize(q, r)); return true;
  };
  const fill = (need, filt, maxPer, pool = cands) => {
    const list = shuffle(pool.filter(filt), r);
    for (let round = 0; need > 0 && round < 40 && list.length; round++) for (const c of list) { if (need > 0 && tryAdd(c, maxPer)) need--; }
    return need;
  };
  let lack = 0;
  for (const [lv, need] of plan) lack += fill(need, (c) => c.lv === lv, perMax);
  if (lack) lack = fill(lack, () => true, perMax + 1);
  if (lack) lack = fill(lack, () => true, 99);
  let filled = 0;
  if (lack && pick) { // 自選的單元不夠多不同的題目：用同年級的其他單元補滿，並讓前端告訴學生
    const grades = [...new Set([...pick].map(gradeOf))], before = out.length;
    const extra = [];
    GENS.filter((g) => grades.includes(gradeOf(g.id)) && !pick.has(g.id)).forEach((g) => extra.push({ kind: "gen", unit: g.id, lv: g.lv }));
    fixedFor(bank, (x) => grades.includes(gradeOf(x.unit)) && !pick.has(x.unit) && x.mock !== "0" && x.mock !== 0).forEach((q) => extra.push({ kind: "fix", unit: q.unit, lv: q.lv, q }));
    lack = fill(lack, () => true, 99, extra); filled = out.length - before;
  }
  const res = out.map((q, i) => [q, i]).sort((a, b) => a[0].lv - b[0].lv || a[1] - b[1]).map((x) => x[0]);
  res.meta = { short: Math.max(0, n - res.length), filled };
  return res;
}

/* ---- 練習卷（出卷）：從選定的單元「輪流」出題，產生器與固定題混著出；某單元的不重複題目用完就由其他單元補 ---- */
export function pickMany({ units, bank, n, r, seen = new Set(), pred = (x) => x.print !== "0" && x.print !== 0 }) {
  const src = units.map((u) => ({ u, gen: GEN_IDS.has(u), fx: shuffle(fixedFor(bank, (x) => x.unit === u && pred(x)), r), dead: false }));
  const out = [];
  const next = (s) => {
    const useFx = s.fx.length && (!s.gen || r() < 0.35);
    if (useFx) { while (s.fx.length) { const q = s.fx.pop(); if (!seen.has(q.q)) { seen.add(q.q); return q; } } }
    if (s.gen) { for (let i = 0; i < 30; i++) { const q = runGen(s.u, r); if (q && !seen.has(q.q)) { seen.add(q.q); return q; } } }
    while (s.fx.length) { const q = s.fx.pop(); if (!seen.has(q.q)) { seen.add(q.q); return q; } }
    s.dead = true; return null;
  };
  while (out.length < n && src.some((s) => !s.dead)) for (const s of src) { if (out.length >= n) break; if (s.dead) continue; const q = next(s); if (q) out.push(q); }
  return out;
}

/* ---- 每日一題：全班同一題（種子＝日期＋班級）。題目來源：產生器，加上試算表裡 daily=1 的固定題 ---- */
export function buildDaily(grade, cls, date, bank = []) {
  const r = rng(date + "|" + cls);
  let units = GENS.filter((g) => gradeOf(g.id) <= grade && gradeOf(g.id) >= grade - 1);
  if (units.length < 3) units = GENS.filter((g) => gradeOf(g.id) <= grade);
  const pool = units.map((g) => ({ gen: g.id })).concat(fixedFor(bank, (x) => x.daily === "1" && gradeOf(x.unit) <= grade && gradeOf(x.unit) >= grade - 1).map((q) => ({ q })));
  const c = pool[ri(r, 0, pool.length - 1)];
  return finalize(c.gen ? runGen(c.gen, r) : { ...c.q }, r);
}

/* ---- 評分 ---- */
export function isCorrect(q, v) {
  if (v === null || v === undefined || v === "") return false;
  if (q.t === "text") { const x = normText(v); return !!x && (q.alt && q.alt.length ? q.alt : [q.a]).some((a) => normText(a) === x); }
  if (q.o) return String(v) === String(q.a);
  const x = +v;
  return Number.isFinite(x) && Math.abs(x - q.a) < 1e-6;
}
export function diagnose(q, v) {
  if (!q.d || v === null || v === undefined || v === "") return "";
  return (q.o ? q.d[String(v)] : q.t === "text" ? q.d[normText(v)] : q.d[key(v)]) || "";
}
/* 給前端的題目（不含答案、提示、診斷） */
export const publicQ = (q, i) => ({ i, unit: q.unit, q: q.q, o: q.o || undefined, t: q.t || undefined, img: q.img || undefined });
