/* 題庫與名單的格式檢查（後端 API 與 tools/build-data.mjs 共用）。
   rows 是物件陣列，欄位名稱小寫，_row 是顯示給人看的列號。 */
export const UNIT_RE = /^[1-6][ud]-\d{1,2}\.\d{1,2}$/;
// 圖片：assets/q/ 底下的檔名、https 網址，或在老師後台上傳的圖片（d:16碼）
export const IMG_RE = /^(https:\/\/[^\s"'<>]+|d:[a-f0-9]{16}|(?!.*\.\.)[\w\-./]+\.(png|jpe?g|gif|svg|webp))$/i;

export function checkBank(rows) {
  const errs = [], ids = new Set(), out = [];
  for (const r of rows) {
    const e = (m) => errs.push(`題庫第 ${r._row} 列：${m}`);
    if (!r.id) { if (Object.values(r).some((v) => v && v !== r._row)) e("缺少 id"); continue; }
    if (ids.has(r.id)) e(`id「${r.id}」重複`); ids.add(r.id);
    if (!UNIT_RE.test(r.unit)) e(`unit「${r.unit}」格式不對，例如 6d-5.3`);
    if (!["num", "choice", "text"].includes(r.type)) e(`type 要填 num、choice 或 text`);
    if (!r.q) e("題目是空的");
    const lv = r.lv === "" ? 2 : +r.lv;
    if (![1, 2, 3].includes(lv)) e("lv 要填 1、2 或 3");
    if (r.type === "num" && !Number.isFinite(+r.answer)) e(`數值題的 answer「${r.answer}」不是數字`);
    if (r.type === "text") {
      const al = String(r.answer || "").split("|").map((s) => s.trim()).filter(Boolean);
      if (!al.length) e("文字題的 answer 不能是空的（可用 | 分隔多個可接受的答案）");
      else if (al.some((s) => s.length > 40)) e("文字題的答案每個最多 40 個字");
    }
    if (r.type === "choice") {
      const o = r.options.split("|").map((s) => s.trim()).filter(Boolean);
      if (o.length < 2) e("選擇題的 options 要用 | 分隔，至少兩個");
      else if (!o.includes(r.answer)) e(`answer「${r.answer}」不在 options 裡`);
      if (new Set(o).size !== o.length) e("options 有重複");
    }
    for (const col of ["img", "himg"]) if (r[col] && !IMG_RE.test(r[col])) e(`${col}「${r[col]}」只能是圖片檔名（png/jpg/svg/webp，放在網站的 assets/q/）或 https 網址`);
    if (r.diag) for (const p of r.diag.split(";;")) if (!p.includes("=>")) e(`diag「${p}」格式要是「錯誤答案=>提示」`);
    out.push({ id: r.id, unit: r.unit, type: r.type, lv, q: r.q, options: r.options, answer: r.answer, hint: r.hint || "", diag: r.diag || "", print: r.print === "0" ? "0" : "1", daily: r.daily === "1" ? "1" : "", mock: r.mock === "0" ? "0" : "1", img: r.img || "", himg: r.himg || "", active: r.active === "0" ? "0" : "1" });
  }
  return { errs, out };
}
export function checkRoster(rows, opt = {}) {
  const errs = [], seen = new Set(), seat = new Set(), out = [];
  for (const r of rows) {
    const e = (m) => errs.push(`名單第 ${r._row} 列：${m}`);
    if (!r.email) continue;
    const em = r.email.toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) e(`email「${r.email}」格式不對`);
    if (seen.has(em)) e(`email「${em}」重複`); seen.add(em);
    const role = r.role === "" ? "student" : r.role;
    if (!["student", "teacher", "admin"].includes(role)) e("role 要填 student、teacher 或 admin");
    if (!r.class) e("缺少 class");
    if (role === "student") {
      if (!(+r.no > 0)) e("學生要有座號 no");
      if (seat.has(r.class + "|" + r.no)) e(`${r.class} 班 ${r.no} 號重複`); seat.add(r.class + "|" + r.no);
    }
    const expires = String(r.expires || "").trim();
    if (expires && !/^\d{4}-\d{2}-\d{2}$/.test(expires)) e(`到期日「${expires}」格式要是 2026-12-31（留空＝不限期）`);
    const grade = r.grade === "" ? 6 : +r.grade;
    if (![1, 2, 3, 4, 5, 6].includes(grade)) e("grade 要填 1 到 6");
    out.push({ email: em, class: r.class, no: +r.no || 0, name: r.name || "", role, grade, active: r.active === "0" ? "0" : "1", expires });
  }
  if (!opt.partial && !out.some((x) => x.role === "admin" && x.active !== "0")) errs.push("名單裡至少要有一位 admin（管理員），否則沒人能管理名單與題庫");
  return { errs, out };
}

