/* 端對端測試：用假的 D1（node:sqlite）、假的 KV、本機假 JWKS，直接呼叫 Worker */
import http from "node:http";
import crypto from "node:crypto";
import fs from "node:fs";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { handle } from "../src/index.js";

/* --- 假 JWKS 伺服器 --- */
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048 });
const other = crypto.generateKeyPairSync("rsa", { modulusLength: 2048 });
const jwk = { ...publicKey.export({ format: "jwk" }), kid: "k1", alg: "RS256", use: "sig" };
const srv = http.createServer((q, s) => { s.setHeader("content-type", "application/json"); s.setHeader("cache-control", "max-age=3600"); s.end(JSON.stringify({ keys: [jwk] })); });
await new Promise((r) => srv.listen(0, r));
const PID = "test-proj";
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
function token(email, o = {}) {
  const now = Math.floor(Date.now() / 1000);
  const claims = { iss: "https://securetoken.google.com/" + PID, aud: PID, sub: "uid-" + email, iat: now - 5, exp: now + 3600, auth_time: now - 5, email, email_verified: true, firebase: { sign_in_provider: "google.com", identities: {} }, ...o.claims };
  const head = b64({ alg: "RS256", kid: "k1", typ: "JWT" }), body = b64(claims);
  const sig = crypto.sign("RSA-SHA256", Buffer.from(head + "." + body), o.key || privateKey).toString("base64url");
  return head + "." + body + "." + sig;
}

/* --- 假 D1 / KV --- */
const sql = new DatabaseSync(":memory:"); sql.exec(fs.readFileSync("schema.sql", "utf8"));
class Stmt { constructor(s) { this.s = s; this.a = []; } bind(...a) { this.a = a; return this; }
  async first() { return sql.prepare(this.s).get(...this.a) || null; }
  async all() { return { results: sql.prepare(this.s).all(...this.a) }; }
  async run() { sql.prepare(this.s).run(...this.a); return { success: true }; }
  sync() { sql.prepare(this.s).run(...this.a); } }
const DB = { prepare: (s) => new Stmt(s), async batch(list) { sql.exec("BEGIN"); try { list.forEach((x) => x.sync()); sql.exec("COMMIT"); } catch (e) { sql.exec("ROLLBACK"); throw e; } return []; } };
const store = { bank: JSON.parse(fs.readFileSync("data-out/bank.json", "utf8")), roster: JSON.parse(fs.readFileSync("data-out/roster.json", "utf8")) };
const KV = { get: async (k) => store[k] };
store.roster.push({ email: "student4@example.com", class: "601", no: 4, name: "小強", role: "student", grade: 6, active: "1" });
const seed = () => {
  store.roster.forEach((x) => sql.prepare("INSERT OR REPLACE INTO roster(email,class,no,name,role,grade,active) VALUES(?,?,?,?,?,?,?)").run(x.email, x.class, x.no, x.name, x.role, x.grade, x.active));
  store.bank.forEach((x) => sql.prepare("INSERT OR REPLACE INTO bank(id,unit,type,lv,q,options,answer,hint,diag,img,himg,print,daily,mock,active,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)").run(x.id, x.unit, x.type, x.lv, x.q, x.options, String(x.answer), x.hint, x.diag, x.img, x.himg, x.print, x.daily, x.mock, x.active));
};
seed();
const env = { DB, KV, FIREBASE_PROJECT_ID: PID, JWKS_URL: `http://127.0.0.1:${srv.address().port}/`, ALLOWED_ORIGINS: "https://good.github.io", ALLOW_LOCALHOST: "0" };

const T1 = "student1@example.com", T2 = "student2@example.com", TEA = "teacher@example.com";
async function api(method, path, tok, body, headers = {}) {
  const res = await handle(new Request("http://w" + path, { method, headers: { ...(tok ? { Authorization: "Bearer " + tok } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }), env);
  return { status: res.status, json: await res.json(), headers: res.headers };
}
let mem_expire = () => {};
const t = (name, fn) => fn().then(() => console.log("✓", name), (e) => { console.error("✗", name); throw e; });
const sess = (sid) => JSON.parse(sql.prepare("SELECT state FROM sessions WHERE id=?").get(sid).state);

await t("沒有 / 假造 / 過期 / 錯專案 / 未驗證 email 的 token 全部擋下", async () => {
  assert.equal((await api("GET", "/api/me")).status, 401);
  assert.equal((await api("GET", "/api/me", "a.b.c")).status, 401);
  assert.equal((await api("GET", "/api/me", token(T1, { key: other.privateKey }))).status, 401, "簽章不對");
  assert.equal((await api("GET", "/api/me", token(T1, { claims: { exp: 1 } }))).status, 401, "過期");
  assert.equal((await api("GET", "/api/me", token(T1, { claims: { aud: "evil", iss: "https://securetoken.google.com/evil" } }))).status, 401, "別人的專案");
  assert.equal((await api("GET", "/api/me", token(T1, { claims: { email_verified: false } }))).status, 401);
  assert.equal((await api("GET", "/api/me", token(T1, { claims: { firebase: { sign_in_provider: "password" } } }))).status, 401, "非 Google 登入");
});
await t("Google 帳號對，但不在名單 → 403", async () => {
  const r = await api("GET", "/api/me", token("stranger@gmail.com")); assert.equal(r.status, 403); assert.equal(r.json.err, "not_in_roster");
});
await t("名單內的同學登入，拿到空白個人資料與貼紙定義", async () => {
  const r = await api("GET", "/api/me", token(T1)); assert.equal(r.status, 200);
  assert.equal(r.json.user.name, "小明"); assert.equal(r.json.data.pts, 0); assert.ok(r.json.stk.length >= 10); assert.ok(!JSON.stringify(r.json.stk).includes("ok"));
});
await t("小測驗：題目不含答案；答錯有診斷；重複送出擋下；完成給積分", async () => {
  const tok = token(T1), s = await api("POST", "/api/start", tok, { kind: "quiz", unit: "5u-9.2" });
  assert.equal(s.status, 200); assert.ok(s.json.qs.length >= 5);
  const raw = JSON.stringify(s.json); assert.ok(!/"a":|"h":|"d":/.test(raw), "題目回應裡不該有答案/提示/診斷：" + raw.slice(0, 200));
  const st = sess(s.json.sid), q0 = st.qs[0];
  const wrongV = Object.keys(q0.d)[0]; assert.ok(wrongV, "應有診斷");
  let r = await api("POST", "/api/check", tok, { sid: s.json.sid, i: 0, v: wrongV });
  assert.equal(r.json.ok, false); assert.ok(r.json.diag.includes("÷ 2")); assert.equal(r.json.a, q0.a);
  assert.equal((await api("POST", "/api/check", tok, { sid: s.json.sid, i: 0, v: q0.a })).status, 409, "同一題不能重答");
  for (let i = 1; i < st.qs.length; i++) assert.equal((await api("POST", "/api/check", tok, { sid: s.json.sid, i, v: st.qs[i].a })).json.ok, true);
  const f = await api("POST", "/api/finish", tok, { sid: s.json.sid });
  assert.equal(f.json.n, st.qs.length); assert.equal(f.json.c, st.qs.length - 1); assert.ok(f.json.gain >= 10 * (st.qs.length - 1) + 20);
  assert.ok(f.json.got.includes("first"));
  assert.equal(f.json.data.wr.length, 1, "答錯進錯題本");
  assert.equal((await api("POST", "/api/finish", tok, { sid: s.json.sid })).status, 409);
});
await t("別人的 session 用不了", async () => {
  const s = await api("POST", "/api/start", token(T1), { kind: "quiz", unit: "5u-9.2" });
  assert.equal((await api("POST", "/api/check", token(T2), { sid: s.json.sid, i: 0, v: 1 })).status, 404);
});
await t("模擬卷：10 題、由易到難、伺服器計時；交卷判分只算一次", async () => {
  const tok = token(T1), s = await api("POST", "/api/start", tok, { kind: "mock" });
  assert.equal(s.json.qs.length, 10); assert.equal(s.json.seconds, 1200);
  const st = sess(s.json.sid), lvs = st.qs.map((q) => q.lv); assert.deepEqual(lvs, [...lvs].sort());
  const ans = st.qs.map((q, i) => (i < 8 ? q.a : "99999"));
  const r = await api("POST", "/api/submit", tok, { sid: s.json.sid, ans });
  assert.equal(r.json.sc, 80); assert.equal(r.json.review.length, 2); assert.ok(r.json.got.includes("m81"));
  assert.equal((await api("POST", "/api/submit", tok, { sid: s.json.sid, ans })).status, 409, "不能重複交卷");
});
await t("模擬卷超時：伺服器拒絕計分（前端改時間沒用）", async () => {
  const tok = token(T2), s = await api("POST", "/api/start", tok, { kind: "mock" }), st = sess(s.json.sid);
  sql.prepare("UPDATE sessions SET deadline=? WHERE id=?").run(Date.now() - 60e3, s.json.sid);
  const r = await api("POST", "/api/submit", tok, { sid: s.json.sid, ans: st.qs.map((q) => q.a) });
  assert.equal(r.json.late, true); assert.equal(r.json.sc, 0);
});
await t("每日一題：同班同一題、只能領一次", async () => {
  const a = await api("POST", "/api/start", token(T1), { kind: "daily" }), b = await api("POST", "/api/start", token(T2), { kind: "daily" });
  assert.equal(a.json.qs[0].q, b.json.qs[0].q, "同班同題");
  const q = sess(a.json.sid).qs[0];
  assert.equal((await api("POST", "/api/check", token(T1), { sid: a.json.sid, i: 0, v: q.a })).json.ok, true);
  const f = await api("POST", "/api/finish", token(T1), { sid: a.json.sid }); assert.ok(f.json.gain >= 30);
  const again = await api("POST", "/api/start", token(T1), { kind: "daily" }); assert.equal(again.json.done, true);
});
await t("防刷：每天超過 100 題後答對不再加分", async () => {
  const tok = token(T2); let last = 0;
  for (let k = 0; k < 40; k++) {
    const s = await api("POST", "/api/start", tok, { kind: "quiz", unit: "6d-5.1" }), st = sess(s.json.sid);
    for (let i = 0; i < st.qs.length; i++) await api("POST", "/api/check", tok, { sid: s.json.sid, i, v: st.qs[i].a });
    last = (await api("POST", "/api/finish", tok, { sid: s.json.sid })).json.gain;
  }
  const me = (await api("GET", "/api/me", tok)).json.data; assert.ok(me.cap.n > 100);
  assert.equal(last, 0, "超過上限後，答對與完成獎勵都不再加分，實際 +" + last);
});
await t("錯題間隔複習：答對後隔天再出現，連過三輪（1/3/7 天）才畢業", async () => {
  const tok = token(T1); let me = (await api("GET", "/api/me", tok)).json.data; const before = me.wr.length; assert.ok(before >= 1);
  const makeDue = () => { const r = sql.prepare("SELECT data FROM profiles WHERE email=?").get(T1), D = JSON.parse(r.data); D.wr.forEach((w) => { if (w.due) w.due = "2000-01-01"; }); sql.prepare("UPDATE profiles SET data=? WHERE email=?").run(JSON.stringify(D), T1); };
  const round = async () => { const s = await api("POST", "/api/start", tok, { kind: "fix" }); if (s.json.empty) return null; const st = sess(s.json.sid); await api("POST", "/api/check", tok, { sid: s.json.sid, i: 0, v: st.qs[0].a }); await api("POST", "/api/finish", tok, { sid: s.json.sid }); return st.qs[0].q; };
  makeDue(); assert.ok(await round(), "第 1 輪");
  me = (await api("GET", "/api/me", tok)).json.data; const w1 = me.wr.find((w) => w.ok === 1); assert.ok(w1 && w1.due > "2000-01-01", "答對一次後應排到之後");
  assert.equal(me.wr.length, before);
  const again = await api("POST", "/api/start", tok, { kind: "fix" }); const dueNow = me.wr.filter((w) => w.due <= me.cap.d || !w.due).length;
  makeDue(); assert.ok(await round(), "第 2 輪"); makeDue(); assert.ok(await round(), "第 3 輪");
  me = (await api("GET", "/api/me", tok)).json.data; assert.equal(me.wr.length, before - 1, "連過三輪才畢業"); assert.equal(me.fx, 1);
});
await t("積分依難度：lv1/2/3 答對各得 10/15/20（可用環境變數調整）", async () => {
  const { rec, blank, cfgOf } = await import("../src/game.js"), D = blank(), c = cfgOf({});
  [1, 2, 3].forEach((lv, i) => { const p = D.pts; rec(D, { unit: "6d-5.3", q: "x" + lv, a: 1, lv }, true, false, c); assert.equal(D.pts - p, [10, 15, 20][i]); });
  const D2 = blank(), c2 = cfgOf({ POINTS_BY_LEVEL: "5,5,50", LEVEL_STEP: "300" }); rec(D2, { unit: "6d-5.3", q: "y", a: 1, lv: 3 }, true, false, c2); assert.equal(D2.pts, 50);
  const { lv } = await import("../src/game.js"); assert.equal(lv({ pts: 299 }, c2), 1); assert.equal(lv({ pts: 300 }, c2), 2);
});
await t("貼紙（勳章）共 150 枚以上、分五階；解鎖條件正確；進度可查", async () => {
  const { STK, blank, award, cfgOf, stkProgress } = await import("../src/game.js"); assert.ok(STK.length >= 150); assert.equal(new Set(STK.map((x) => x.id)).size, STK.length);
  assert.deepEqual([...new Set(STK.map((x) => x.t))].sort(), [1, 2, 3, 4, 5]);
  const D = blank(); D.u["6d-5.3"] = { n: 33, c: 31 }; D.pf = 3; D.pts = 1500; D.mk = [{ sc: 100 }, { sc: 90 }, { sc: 85 }]; D.sk.n = 14; D.dn = 20; D.ex.early = 1;
  const got = award(D, cfgOf({})); for (const id of ["c10", "p3", "ms1", "m11", "m81", "steady", "s14", "pts1000", "mk1", "dn20", "eb1", "g630"]) assert.ok(got.includes(id), id + " 應解鎖");
  assert.ok(!got.includes("c1000") && !got.includes("s30") && !got.includes("we1"));
  const pr = stkProgress(D, cfgOf({})); assert.equal(pr.s.target, 21); assert.equal(pr.s.cur, 14);
  assert.ok(D.pts > 1500, "解鎖貼紙給積分（依階級）");
});
await t("每日一題防刷：同一天只能算一次；中途離開、重開、重複送出、同時送出都不能重複拿分", async () => {
  const tok = token("student4@example.com"), s1 = await api("POST", "/api/start", tok, { kind: "daily" }), s2 = await api("POST", "/api/start", tok, { kind: "daily" });
  assert.equal(s1.json.sid, s2.json.sid, "沒作答前重開，沿用同一份");
  const q = sess(s1.json.sid).qs[0], p0 = (await api("GET", "/api/me", tok)).json.data.pts;
  const [r1, r2] = await Promise.all([api("POST", "/api/check", tok, { sid: s1.json.sid, i: 0, v: q.a }), api("POST", "/api/check", tok, { sid: s1.json.sid, i: 0, v: q.a })]);
  assert.deepEqual([r1.status, r2.status].sort(), [200, 409], "同時送出只有一個成功");
  const me = (await api("GET", "/api/me", tok)).json.data, t = Object.keys(me.dq)[0];
  assert.equal(me.dq[t].ok, true); assert.equal(me.pts - p0, (r1.status === 200 ? r1 : r2).json.gain);
  assert.ok((r1.status === 200 ? r1 : r2).json.gain >= 30 && (r1.status === 200 ? r1 : r2).json.gain < 120, "只領一次 30 分（外加勳章/連續天數）");
  const again = await api("POST", "/api/start", tok, { kind: "daily" }); assert.equal(again.json.done, true, "答完後再進來顯示已完成");
  // 偷開第二份每日一題 session（模擬舊分頁、或直接呼叫 API）也不能再算
  sql.prepare("INSERT INTO sessions(id,email,kind,created,deadline,done,state) VALUES('manual-daily','student4@example.com','daily',?,NULL,0,?)").run(Date.now(), JSON.stringify({ qs: [q], ans: {} }));
  assert.equal((await api("POST", "/api/check", tok, { sid: "manual-daily", i: 0, v: q.a })).status, 409);
  assert.equal((await api("GET", "/api/me", tok)).json.data.pts, me.pts, "積分沒有再增加");
  const fin = await api("POST", "/api/finish", tok, { sid: s1.json.sid }); assert.equal(fin.status, 200); assert.equal(fin.json.gain, (r1.status === 200 ? r1 : r2).json.gain);
  assert.equal((await api("POST", "/api/finish", tok, { sid: s1.json.sid })).status, 409);
});
await t("答錯的每日一題也只算一次（+5），而且進錯題本", async () => {
  sql.prepare("DELETE FROM once WHERE k LIKE 'daily:student4%'").run(); const D = JSON.parse(sql.prepare("SELECT data FROM profiles WHERE email='student4@example.com'").get().data); D.dq = {}; sql.prepare("UPDATE profiles SET data=? WHERE email='student4@example.com'").run(JSON.stringify(D));
  sql.exec("DELETE FROM sessions WHERE id='manual-daily'");
  const tok = token("student4@example.com"), s = await api("POST", "/api/start", tok, { kind: "daily" }), p0 = (await api("GET", "/api/me", tok)).json.data.pts;
  const r = await api("POST", "/api/check", tok, { sid: s.json.sid, i: 0, v: "-12345" }); assert.equal(r.json.ok, false); assert.ok(r.json.gain >= 5 && r.json.gain < 60);
  assert.ok((await api("GET", "/api/me", tok)).json.data.wr.length >= 1);
});
await t("小測驗同時送出同一題：只會計分一次", async () => {
  const tok = token("student4@example.com"), s = await api("POST", "/api/start", tok, { kind: "quiz", unit: "6d-5.1" }), st = sess(s.json.sid), p0 = (await api("GET", "/api/me", tok)).json.data.pts;
  const rs = await Promise.all([1, 2, 3, 4, 5].map(() => api("POST", "/api/check", tok, { sid: s.json.sid, i: 0, v: st.qs[0].a })));
  assert.equal(rs.filter((r) => r.status === 200).length, 1); assert.equal((await api("GET", "/api/me", tok)).json.data.pts - p0, 15);
});
await t("圖片欄位會傳給前端；daily=1 的固定題進入每日一題池；mock=0 的不進模擬卷", async () => {
  const s = await api("POST", "/api/start", token(T1), { kind: "quiz", unit: "6d-3.1" }); assert.ok(s.json.qs.some((q) => q.img === "demo-prism.svg"), "固定題的圖片欄位");
  for (let i = 0; i < 30; i++) { const m = await api("POST", "/api/start", token(T1), { kind: "mock" }); const st = sess(m.json.sid); assert.ok(st.qs.every((q) => !/-f\d+$/.test(q.qid)), "匯入的挑戰題不該進模擬卷"); }
});
await t("排行榜只含同班學生", async () => {
  const r = await api("GET", "/api/board", token(T1)); assert.ok(r.json.rows.length >= 2); assert.ok(r.json.rows.every((x) => x.n !== "老師"));
});
await t("列印練習卷：只包含 print=1 的固定題，其餘固定題不會洩漏", async () => {
  const tok = token(T2);
  const r = await api("GET", "/api/print?src=5u-9.2&n=10", tok); assert.equal(r.status, 200);
  const all = sql.prepare("SELECT q,print FROM bank").all(), printable = all.filter((b) => b.print === "1").map((b) => b.q), hidden = all.filter((b) => b.print !== "1").map((b) => b.q);
  assert.ok(r.json.qs.some((q) => printable.includes(q.q)), "print=1 的題目應出現"); assert.ok(r.json.qs.every((q) => !hidden.includes(q.q)));
  const t2 = await api("GET", "/api/print?src=mix&n=10&g=3", token(TEA)); assert.equal(t2.status, 200);
});
await t("老師後台：學生 403、老師看得到全班與迷思統計", async () => {
  assert.equal((await api("GET", "/api/admin/overview", token(T1))).status, 403);
  const r = await api("GET", "/api/admin/overview", token(TEA)); assert.equal(r.status, 200);
  assert.ok(r.json.students.length >= 2); assert.ok(r.json.units.length >= 1); assert.ok(r.json.never.some((x) => x.name === "小美")); assert.ok(r.json.misconceptions.length >= 1);
});
await t("CORS：只允許名單內的網站", async () => {
  const ok = await api("GET", "/api/health", null, null, { Origin: "https://good.github.io" }); assert.equal(ok.headers.get("access-control-allow-origin"), "https://good.github.io");
  const no = await api("GET", "/api/health", null, null, { Origin: "https://evil.example" }); assert.equal(no.headers.get("access-control-allow-origin"), null);
});
await t("老師可重設／刪除學生資料；學生不行", async () => {
  assert.equal((await api("POST", "/api/admin/delete", token(T1), { cls: "601", no: 1, mode: "delete" })).status, 403);
  assert.equal((await api("POST", "/api/admin/delete", token(TEA), { cls: "601", no: 3, mode: "delete" })).status, 404, "沒登入過的學生沒有資料");
  const n0 = sql.prepare("SELECT COUNT(*) c FROM attempts WHERE email=?").get(T1).c; assert.ok(n0 > 0);
  assert.equal((await api("POST", "/api/admin/delete", token(TEA), { cls: "601", no: 1, mode: "reset" })).json.ok, true);
  const me = (await api("GET", "/api/me", token(T1))).json.data; assert.equal(me.pts, 0); assert.equal(sql.prepare("SELECT COUNT(*) c FROM attempts WHERE email=?").get(T1).c, 0);
  await api("GET", "/api/me", token(T1)); assert.equal((await api("POST", "/api/admin/delete", token(TEA), { cls: "601", no: 1, mode: "delete" })).json.ok, true);
  assert.equal(sql.prepare("SELECT COUNT(*) c FROM profiles WHERE email=?").get(T1).c, 0, "profile 應被刪除");
  assert.equal(sql.prepare("SELECT COUNT(*) c FROM sessions WHERE email=?").get(T1).c, 0);
});
await t("名單移除：老師在後台刪除後，學生立刻失去權限", async () => {
  assert.equal((await api("GET", "/api/me", token(T2))).status, 200);
  assert.equal((await api("POST", "/api/admin/roster/delete", token(TEA), { email: T2 })).json.ok, true);
  assert.equal((await api("GET", "/api/me", token(T2))).status, 403);
});
await t("後台名單管理：新增／改名／座號衝突／不能自毀／學生不能用", async () => {
  const row = { email: "New.Kid@Gmail.com", class: "601", no: 9, name: "小新", role: "student", grade: 6 };
  assert.equal((await api("POST", "/api/admin/roster", token(T1), { rows: [row] })).status, 403);
  assert.equal((await api("GET", "/api/me", token("newkid@gmail.com"))).status, 403);
  assert.equal((await api("POST", "/api/admin/roster", token(TEA), { rows: [row] })).json.ok, true);
  assert.equal((await api("GET", "/api/me", token("newkid@gmail.com"))).json.user.name, "小新", "gmail 大小寫與點號不影響");
  const dup = await api("POST", "/api/admin/roster", token(TEA), { rows: [{ ...row, email: "other@x.com" }] }); assert.equal(dup.json.ok, false); assert.ok(dup.json.errs[0].includes("已經有人"));
  const self = await api("POST", "/api/admin/roster", token(TEA), { rows: [{ email: TEA, class: "all", no: 0, name: "老師", role: "student" }] }); assert.equal(self.json.ok, false);
  assert.equal((await api("POST", "/api/admin/roster/delete", token(TEA), { email: TEA })).status, 400);
  const bad = await api("POST", "/api/admin/roster", token(TEA), { rows: [{ email: "nope", class: "601", no: 1, role: "student" }] }); assert.equal(bad.json.ok, false);
  const list = await api("GET", "/api/admin/roster", token(TEA)); assert.ok(list.json.rows.some((x) => x.email === "new.kid@gmail.com"));
});
await t("後台題庫管理：新增（含圖片與診斷）→ 學生立刻考得到；格式錯誤會擋；可刪除", async () => {
  const good = { unit: "5u-9.2", type: "num", lv: "3", q: "測試題：底 7、高 4 的三角形，面積？", answer: "14", hint: "7×4÷2", diag: "28=>忘了除以 2", img: "d:0123456789abcdef", print: "1", mock: "1", active: "1" };
  assert.equal((await api("POST", "/api/admin/bank", token(T1), { rows: [good] })).status, 403);
  const badRow = await api("POST", "/api/admin/bank", token(TEA), { rows: [{ ...good, type: "choice", options: "a|b", answer: "zzz" }] }); assert.equal(badRow.json.ok, false); assert.ok(badRow.json.errs[0].includes("不在 options"));
  assert.equal((await api("POST", "/api/admin/bank", token(TEA), { rows: [{ ...good, img: "../../etc/passwd" }] })).json.ok, false, "路徑穿越要擋");
  const ok = await api("POST", "/api/admin/bank", token(TEA), { rows: [good] }); assert.equal(ok.json.ok, true); const id = ok.json.ids[0];
  let found = null; for (let i = 0; i < 40 && !found; i++) { const s = await api("POST", "/api/start", token("newkid@gmail.com"), { kind: "quiz", unit: "5u-9.2" }); found = s.json.qs.find((q) => q.q.startsWith("測試題")); }
  assert.ok(found, "新增的題目應立刻可用"); assert.equal(found.img, "d:0123456789abcdef");
  const sid = (await api("POST", "/api/start", token("newkid@gmail.com"), { kind: "quiz", unit: "5u-9.2" })).json.sid; void sid;
  assert.equal((await api("POST", "/api/admin/bank/delete", token(TEA), { ids: [id] })).json.ok, true);
  assert.ok(!sql.prepare("SELECT 1 FROM bank WHERE id=?").get(id));
  const imp = await api("POST", "/api/admin/bank", token(TEA), { rows: [{ ...good, id: "imp-1" }, { ...good, id: "imp-2", q: "第二題" }], mode: "merge" }); assert.equal(imp.json.n, 2);
});
await t("圖片上傳：只有老師能傳，格式與大小受限，傳完公開網址可讀", async () => {
  const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64").toString("base64");
  assert.equal((await api("POST", "/api/admin/image", token(T1), { mime: "image/png", b64: png })).status, 403);
  assert.equal((await api("POST", "/api/admin/image", token(TEA), { mime: "text/html", b64: png })).status, 400);
  assert.equal((await api("POST", "/api/admin/image", token(TEA), { mime: "image/png", b64: "<script>" })).status, 400);
  const r = await api("POST", "/api/admin/image", token(TEA), { mime: "image/png", b64: png }); assert.ok(/^d:[a-f0-9]{16}$/.test(r.json.ref));
  const img = await handle(new Request("http://w/api/img/" + r.json.ref.slice(2)), env); assert.equal(img.status, 200); assert.equal(img.headers.get("content-type"), "image/png"); assert.equal(Buffer.from(await img.arrayBuffer()).toString("base64"), png);
  assert.equal((await handle(new Request("http://w/api/img/0000000000000000"), env)).status, 404);
});
await t("後台設定：改積分與升級門檻，立刻對新作答生效；數值不合理會擋", async () => {
  assert.equal((await api("POST", "/api/admin/settings", token(T1), { LEVEL_STEP: 100 })).status, 403);
  assert.equal((await api("POST", "/api/admin/settings", token(TEA), { POINTS_BY_LEVEL: "1,2" })).status, 400);
  assert.equal((await api("POST", "/api/admin/settings", token(TEA), { LEVEL_STEP: "5" })).status, 400);
  assert.equal((await api("POST", "/api/admin/settings", token(TEA), { POINTS_BY_LEVEL: "5,5,50", LEVEL_STEP: "300", REVIEW_DAYS: "2,5" })).json.ok, true);
  const me = (await api("GET", "/api/me", token("newkid@gmail.com"))).json; assert.equal(me.cfg.step, 300); assert.deepEqual(me.cfg.pts, [5, 5, 50]); assert.deepEqual(me.cfg.review, [2, 5]);
  await api("POST", "/api/admin/settings", token(TEA), {});
  assert.equal((await api("GET", "/api/me", token("newkid@gmail.com"))).json.cfg.step, 150, "清空設定就回到預設");
});
await t("出卷：選 10 題、30 題都給足題數（單元不夠就用同年級其他單元補）；選項是 A/B/C/D 且順序會隨機", async () => {
  const tok = token(T1);
  for (const n of [10, 30]) {
    const r = await api("GET", `/api/print?src=6u-7.1&n=${n}`, tok); assert.equal(r.status, 200);
    assert.equal(r.json.qs.length, n, `要 ${n} 題`); assert.equal(r.json.short, 0);
    r.json.qs.filter((q) => q.o).forEach((q) => { assert.ok(q.al && "ABCDEFGH".includes(q.al)); assert.equal(q.o["ABCDEFGH".indexOf(q.al)], String(q.a)); });
  }
  const many = await api("GET", "/api/print?src=mix&n=40", tok); assert.equal(many.json.qs.length, 40);
  const orders = new Set(); for (let i = 0; i < 12; i++) { const r = await api("GET", "/api/print?units=6d-5.1,6d-5.3,6u-7.1&n=20", tok); r.json.qs.filter((q) => q.o).forEach((q) => orders.add(q.q + "|" + q.o.join(","))); }
  const byQ = {}; [...orders].forEach((x) => { const [q, o] = x.split("|"); (byQ[q] = byQ[q] || new Set()).add(o); });
  if (Object.keys(byQ).length) assert.ok(Object.values(byQ).some((v) => v.size > 1) || Object.keys(byQ).length < 1, "同一題的選項順序應該會變");
});
await t("模擬卷可自選單元與題數", async () => {
  const tok = token(T1), r = await api("POST", "/api/start", tok, { kind: "mock", units: ["6d-5.1", "6d-5.3"], n: 6 });
  assert.equal(r.status, 200); assert.equal(r.json.qs.length, 6); assert.ok(r.json.qs.every((q) => ["6d-5.1", "6d-5.3"].includes(q.unit)));
  assert.equal(r.json.seconds, 6 * 120);
  const r2 = await api("POST", "/api/start", tok, { kind: "mock", n: 3 }); assert.equal(r2.json.qs.length, 5, "最少 5 題");
});
await t("提示：第一次看扣分、同題不重複扣、答對只拿一半、不會扣成負數、答完不能再看", async () => {
  const T3 = "student3@example.com", tok = token(T3); await api("GET", "/api/me", tok);
  sql.prepare("UPDATE profiles SET data=json_set(data,'$.pts',50,'$.hn',0) WHERE email=?").run(T3);
  const s = await api("POST", "/api/start", tok, { kind: "quiz", unit: "6d-5.1" }), p0 = (await api("GET", "/api/me", tok)).json.data.pts;
  const h1 = await api("POST", "/api/hint", tok, { sid: s.json.sid, i: 0 }); assert.equal(h1.status, 200); assert.equal(h1.json.cost, 3);
  const h2 = await api("POST", "/api/hint", tok, { sid: s.json.sid, i: 0 }); assert.equal(h2.json.cost, 0);
  const me1 = (await api("GET", "/api/me", tok)).json.data; assert.equal(me1.pts, p0 - 3); assert.equal(me1.hn, 1);
  const st = sess(s.json.sid), c = await api("POST", "/api/check", tok, { sid: s.json.sid, i: 0, v: st.qs[0].a }); assert.equal(c.json.ok, true);
  assert.equal((await api("GET", "/api/me", tok)).json.data.pts - me1.pts, Math.floor([10, 15, 20][st.qs[0].lv - 1] * 0.5), "有看提示只拿一半");
  assert.equal((await api("POST", "/api/hint", tok, { sid: s.json.sid, i: 0 })).status, 409);
  sql.prepare("UPDATE profiles SET data=json_set(data,'$.pts',1) WHERE email=?").run(T3);
  const s2 = await api("POST", "/api/start", tok, { kind: "quiz", unit: "6d-5.1" }); await api("POST", "/api/hint", tok, { sid: s2.json.sid, i: 0 });
  assert.equal((await api("GET", "/api/me", tok)).json.data.pts, 0, "扣到 0 為止");
  const ad = await api("POST", "/api/admin/settings", token(TEA), { HINT_COST: "0" }); assert.equal(ad.status, 200);
  const s3 = await api("POST", "/api/start", tok, { kind: "quiz", unit: "6d-5.1" }), h3 = await api("POST", "/api/hint", tok, { sid: s3.json.sid, i: 0 }); assert.equal(h3.json.cost, 0);
  await api("POST", "/api/admin/settings", token(TEA), { HINT_COST: "3" });
});
await t("授權到期：過期的學生不能練習／考試／列印／排行榜，只能看資料；延期後恢復；老師不受限", async () => {
  const tea = token(TEA), E = "student5@example.com", tok = token(E);
  const add = await api("POST", "/api/admin/roster", tea, { rows: [{ email: E, class: "601", no: 5, name: "小愛", role: "student", grade: 6, expires: "2020-01-01" }] }); assert.equal(add.status, 200); assert.equal(add.json.ok, true);
  const bad = await api("POST", "/api/admin/roster", tea, { rows: [{ email: E, class: "601", no: 5, name: "小愛", role: "student", grade: 6, expires: "明年" }] }); assert.equal(bad.json.ok, false);
  const me = await api("GET", "/api/me", tok); assert.equal(me.status, 200); assert.equal(me.json.acct.expired, true);
  for (const [m, p, b] of [["POST", "/api/start", { kind: "quiz", unit: "6d-5.1" }], ["POST", "/api/start", { kind: "mock" }], ["GET", "/api/print?src=mix&n=5"], ["GET", "/api/board"]]) {
    const r = await api(m, p, tok, b); assert.equal(r.status, 403, p); assert.equal(r.json.err, "expired");
  }
  assert.equal((await api("POST", "/api/admin/roster/expire", tea, { cls: "601", date: "2099-12-31" })).status, 200);
  await new Promise((r) => setTimeout(r, 0)); const ok = await api("POST", "/api/start", tok, { kind: "quiz", unit: "6d-5.1" }); assert.equal(ok.status, 200);
  assert.equal((await api("GET", "/api/me", tok)).json.acct.expired, false);
  await api("POST", "/api/admin/roster", tea, { rows: [{ email: E, class: "601", no: 5, name: "小愛二", role: "student", grade: 6 }] });
  assert.equal(sql.prepare("SELECT expires FROM roster WHERE email=?").get(E).expires, "2099-12-31", "沒帶到期日的更新不會清掉期限");
  assert.equal((await api("POST", "/api/admin/roster/expire", tok, { cls: "601", date: "" })).status, 403, "學生不能改期限");
  assert.equal((await api("POST", "/api/admin/roster/expire", tea, { cls: "601", date: "" })).status, 200);
});
await t("後台深度分析：總覽、每日趨勢、時段、風險標記；單一學生檔案", async () => {
  const tea = token(TEA), r = await api("GET", "/api/admin/overview?cls=601", tea); assert.equal(r.status, 200);
  assert.ok(r.json.summary && r.json.summary.total >= 4 && Array.isArray(r.json.daily) && Array.isArray(r.json.hours));
  assert.ok(r.json.students.every((x) => Array.isArray(x.flags) && typeof x.hints === "number"));
  const d = await api("GET", "/api/admin/student?cls=601&no=4", tea); assert.equal(d.status, 200); assert.ok(Array.isArray(d.json.units) && Array.isArray(d.json.log) && Array.isArray(d.json.wrong));
  assert.equal((await api("GET", "/api/admin/student?cls=601&no=4", token(T1))).status, 403);
});
await t("舊資料搬家：D1 還是空的時沿用 KV；按一次搬進 D1，之後由後台管理", async () => {
  for (const tb of ["roster", "bank"]) sql.exec("DELETE FROM " + tb); sql.exec("DELETE FROM settings WHERE k='ver'");
  store.roster = [{ email: TEA, class: "all", no: 0, name: "老師", role: "admin", grade: 6, active: "1" }, { email: "kv@x.com", class: "601", no: 5, name: "KV生", role: "student", grade: 6, active: "1" }];
  store.bank = [{ id: "kv-1", unit: "5u-9.2", type: "num", lv: 2, q: "KV題", options: "", answer: "3", hint: "", diag: "", img: "", himg: "", print: "", daily: "", mock: "1", active: "1" }];
  const realNow = Date.now; Date.now = () => realNow() + 120e3;
  try {
    assert.equal((await api("GET", "/api/me", token("kv@x.com"))).status, 200, "沿用 KV");
    const ov = await api("GET", "/api/admin/roster", token(TEA)); assert.equal(ov.json.legacy, true);
    assert.equal((await api("POST", "/api/admin/migrate", token(T1))).status, 403);
    const m = await api("POST", "/api/admin/migrate", token(TEA)); assert.equal(m.json.roster, 2); assert.equal(m.json.bank, 1);
    store.roster = []; store.bank = [];
    assert.equal((await api("GET", "/api/me", token("kv@x.com"))).status, 200, "搬完後不再依賴 KV");
    assert.equal((await api("GET", "/api/admin/roster", token(TEA))).json.legacy, false);
  } finally { Date.now = realNow; }
});

await t("三級權限：老師只能管自己班的學生；題庫、設定、圖片、搬家只有管理員", async () => {
  sql.exec("DELETE FROM roster"); sql.exec("DELETE FROM settings WHERE k='ver'"); store.roster = []; store.bank = [];
  const R = sql.prepare("INSERT INTO roster(email,class,no,name,role,grade,active) VALUES(?,?,?,?,?,?,?)");
  R.run(TEA, "all", 0, "管理員", "admin", 6, "1"); R.run("t601@x.com", "601,603", 0, "甲", "teacher", 6, "1"); R.run("t602@x.com", "602", 0, "乙", "teacher", 6, "1");
  R.run("s1@x.com", "601", 1, "一", "student", 6, "1"); R.run("s2@x.com", "602", 1, "二", "student", 6, "1");
  const realNow = Date.now; Date.now = () => realNow() + 240e3;
  try {
    const A = token("t601@x.com"), ok = (r) => r.status === 200 && r.json.ok !== false;
    const ros = await api("GET", "/api/admin/roster", A); assert.ok(ros.json.rows.length === 1 && ros.json.rows[0].email === "s1@x.com", "只看得到自己班學生");
    const row = (email, cls, role) => ({ email, class: cls, no: "7", name: "x", role, grade: "6" });
    assert.equal((await api("POST", "/api/admin/roster", A, { rows: [row("s1@x.com", "601", "teacher")] })).json.ok, false, "不能升人當老師");
    assert.equal((await api("POST", "/api/admin/roster", A, { rows: [row(TEA, "601", "student")] })).json.ok, false, "不能降管理員");
    assert.equal((await api("POST", "/api/admin/roster", A, { rows: [row("s2@x.com", "601", "student")] })).json.ok, false, "不能搶別班學生");
    assert.equal((await api("POST", "/api/admin/roster", A, { rows: [row("n@x.com", "602", "student")] })).json.ok, false, "不能加到別班");
    assert.equal(sql.prepare("SELECT role FROM roster WHERE email=?").get(TEA).role, "admin");
    assert.equal((await api("POST", "/api/admin/roster", A, { rows: [row("n@x.com", "603", "student")] })).json.ok, true, "自己的第二個班可以");
    assert.equal((await api("POST", "/api/admin/roster/delete", A, { email: TEA })).status, 403);
    assert.equal((await api("POST", "/api/admin/roster/delete", A, { email: "s2@x.com" })).status, 403);
    assert.equal((await api("POST", "/api/admin/roster/expire", A, { cls: "602", date: "2030-01-01" })).status, 403);
    assert.equal((await api("POST", "/api/admin/roster/expire", A, { emails: ["t602@x.com"], date: "2030-01-01" })).status, 403);
    assert.equal((await api("POST", "/api/admin/roster/expire", A, { cls: "601", date: "2030-01-01" })).status, 200);
    assert.equal((await api("GET", "/api/admin/overview?cls=602", A)).json.cls, "601", "別班看不到，退回自己的班");
    assert.equal((await api("GET", "/api/admin/student?cls=602&no=1", A)).status, 403);
    assert.equal((await api("POST", "/api/admin/delete", A, { cls: "602", mode: "class" })).status, 403);
    for (const [p, b] of [["bank", { rows: [] }], ["bank/delete", { ids: [] }], ["settings", { HINT_COST: "1" }], ["image", {}], ["migrate", {}]])
      assert.equal((await api("POST", "/api/admin/" + p, A, b)).status, 403, p + " 老師不行");
    assert.equal((await api("GET", "/api/admin/bank", A)).status, 200, "老師可以看題庫");
    const M = token(TEA);
    assert.equal((await api("POST", "/api/admin/roster", M, { rows: [row("t602@x.com", "602", "teacher")] })).json.ok, true, "管理員可以設老師");
    assert.equal((await api("POST", "/api/admin/roster", M, { rows: [row(TEA, "all", "teacher")] })).json.ok, false, "管理員不能降級自己");
    assert.equal((await api("POST", "/api/admin/settings", M, { HINT_COST: "2" })).status, 200);
    assert.equal((await api("GET", "/api/admin/roster", M)).json.rows.length >= 5, true);
  } finally { Date.now = realNow; }
});

await t("老師使用期限：到期的老師進不了後台，管理員不受限，只有管理員能設老師期限", async () => {
  const R = sql.prepare("INSERT OR REPLACE INTO roster(email,class,no,name,role,grade,active,expires) VALUES(?,?,?,?,?,?,?,?)");
  R.run("texp@x.com", "601", 0, "期", "teacher", 6, "1", "2020-01-01"); R.run(TEA, "all", 0, "管理員", "admin", 6, "1", "2020-01-01"); sql.exec("INSERT OR REPLACE INTO settings(k,v) VALUES('ver','exp1')");
  const realNow = Date.now; Date.now = () => realNow() + 600e3;
  try {
    assert.equal((await api("GET", "/api/admin/roster", token("texp@x.com"))).json.err, "expired");
    assert.equal((await api("GET", "/api/admin/roster", token(TEA))).status, 200, "管理員不看期限");
    const M = token(TEA);
    assert.equal((await api("POST", "/api/admin/roster/expire", M, { emails: ["texp@x.com"], date: "2099-12-31" })).status, 200);
    assert.equal((await api("GET", "/api/admin/roster", token("texp@x.com"))).status, 200, "延長後恢復");
    assert.equal((await api("POST", "/api/admin/roster/expire", token("texp@x.com"), { emails: ["texp@x.com"], date: "" })).status, 403, "老師不能幫自己延長");
  } finally { Date.now = realNow; }
});

await t("一、二年級：名單可填年級 1–2；出題、每日一題、模擬卷都抓得到低年級單元", async () => {
  const M = token(TEA), row = (email, no, g) => ({ email, class: "101", no, name: "低年級" + g, role: "student", grade: g });
  assert.equal((await api("POST", "/api/admin/roster", M, { rows: [row("g1@x.com", 1, 1), row("g2@x.com", 2, 2)] })).json.ok, true);
  assert.equal((await api("POST", "/api/admin/roster", M, { rows: [row("g0@x.com", 3, 0)] })).json.ok, false, "0 年級不合法");
  const realNow = Date.now; Date.now = () => realNow() + 900e3;
  try {
    const g1 = token("g1@x.com"), g2 = token("g2@x.com");
    assert.equal((await api("GET", "/api/me", g1)).json.user.grade, 1);
    assert.equal((await api("GET", "/api/me", g2)).json.user.grade, 2);
    const s = await api("POST", "/api/start", g1, { kind: "quiz", unit: "1u-7.3" }); assert.equal(s.status, 200); assert.ok(s.json.qs.length >= 5 && s.json.qs.every((q) => q.unit === "1u-7.3"));
    const d = await api("POST", "/api/start", g1, { kind: "daily" }); assert.equal(d.status, 200); assert.ok(/^[12][ud]-/.test(d.json.qs[0].unit), "每日一題是一二年級的單元：" + d.json.qs[0].unit);
    const m = await api("POST", "/api/start", g2, { kind: "mock", n: 10 }); assert.equal(m.status, 200); assert.ok(m.json.qs.every((q) => +q.unit[0] <= 2), "二年級模擬卷只會出一二年級");
    const m1 = await api("POST", "/api/start", g1, { kind: "mock", n: 10, units: ["2u-7.2"] }); assert.equal(m1.status, 200);
  } finally { Date.now = realNow; }
});
srv.close();
console.log("端對端測試全部通過");
